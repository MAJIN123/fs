//���һ��һά���飬ÿ��k����

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void Print_Arr(int arr[], int n, int k);

void main()
{
	int arr[100],i;

	srand(time(NULL));
	for(i = 0;i < 100;i++)
	{
		arr[i] = rand() % 1000;
	}

	Print_Arr(arr,100,10);
}

void Print_Arr(int Arr[],int N,int K)
{
	int i;

	for(i = 0;i < N;i++)
	{
		printf("%-5d",Arr[i]);

		if ((i+1) % K == 0)
		{
			printf("\n");
		}
	}
	
	if(i % 10 != 0)
	{
		printf("\n");
	}
}