//����ѭ������һλ����ֵΪ�ұ��������

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int Array_Shift_Right(int*, int);

void main()
{
	int arr[20],i;

	printf("The original array is:\n");
	srand(time(NULL));
	for(i = 0;i < 20;i++)
	{
		arr[i] = rand() % 1000;
		printf("%-5d",arr[i]);

		if ((i+1) % 10 == 0)
		{
			printf("\n");
		}
	}
	if (i % 10 != 0)
	{
		printf("\n");
	}
	printf("\n");

	arr[0] = Array_Shift_Right(arr,20);

	printf("The new array is:\n");
	for(i = 0;i < 20;i++)
	{
		printf("%-5d",arr[i]);

		if ((i+1) % 10 == 0)
		{
			printf("\n");
		}
	}
	if (i % 10 != 0)
	{
		printf("\n");
	}
}

int Array_Shift_Right(int Arr[], int N)
{
	int tmp = Arr[19],i;

	for(i = 19;i > 0;i--)
	{
		Arr[i] = Arr[i-1];
	}

	return tmp;
}