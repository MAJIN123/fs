//�����ַ����ĳ���

#include<stdio.h>

int Getstrlen(char*);

void main()
{
	char str[1001];

	printf("Please input a string:\n");
	gets(str);

	printf("The length of the string is : %d\n",Getstrlen(str));
}

int Getstrlen(char Str[])
{
	int len = 0,i = 0;

	while(Str[i++] != '\0')
	{
		len++;
	}

	return len;
}