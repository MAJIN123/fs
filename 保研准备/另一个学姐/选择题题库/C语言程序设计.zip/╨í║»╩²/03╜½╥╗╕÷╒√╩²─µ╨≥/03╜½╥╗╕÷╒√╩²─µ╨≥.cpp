//��һ����������

#include <stdio.h>

int Reverse(int);

void main()
{
	int n;

	printf("Please input a number:\n");
	scanf("%d",&n);

	printf("The new number is : %d\n",Reverse(n));
}

int Reverse(int N)
{
	int n = 0;

	while(N > 0)
	{
		n = n * 10 + (N % 10);
		N /= 10;
	}

	return n;
}