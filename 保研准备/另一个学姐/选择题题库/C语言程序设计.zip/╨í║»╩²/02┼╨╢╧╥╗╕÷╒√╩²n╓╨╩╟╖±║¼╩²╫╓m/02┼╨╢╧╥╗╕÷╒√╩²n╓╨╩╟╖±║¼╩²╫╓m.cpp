//�ж�һ������n���Ƿ�����m

#include <stdio.h>

int Exists(int n, int m);

void main()
{
	int n,m;

	printf("Please input a number:\n");
	scanf("%d",&n);

	printf("Please input the number you want to find:\n");
	scanf("%d",&m);

	if (Exists(n,m))
	{
		printf("Yes\n");
	}
	else
	{
		printf("No\n");
	}
}

int Exists(int N,int M)
{
	if (N < 10)
	{
		if(N == M)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	else
	{
		if (N % 10 == M)
		{
			return 1;
		}
		else
		{
			Exists(N/10,M);
		}
	}

}