//01.	�ж�һ�������Ƿ�������

#include <stdio.h>

int Isprime(int);

void main()
{
	int n;

	printf("Please input a number:\n");
	scanf("%d",&n);

	if(Isprime(n))
	{
		printf("%d is a prime\n",n);
	}
	else
	{
		printf("%d isn't a prime\n",n);
	}
}

int Isprime(int N)
{
	int i,prime = 0;
	
	for(i = 1;i <= N;i++)
	{
		if (N % i == 0)
		{
			prime++;
		}
	}

	if (prime == 2)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}