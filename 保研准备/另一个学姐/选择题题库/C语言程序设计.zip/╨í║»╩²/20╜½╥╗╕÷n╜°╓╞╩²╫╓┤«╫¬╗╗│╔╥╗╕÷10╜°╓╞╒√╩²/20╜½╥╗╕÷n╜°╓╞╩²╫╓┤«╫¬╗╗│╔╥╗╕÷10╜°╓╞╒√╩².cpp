//��һ��n�������ִ�ת����һ��10��������

#include <stdio.h>
#include <string.h>
#include <math.h>

int Get_Number(char*, int);

void main()
{
	char str[1001];
	int n;

	printf("Please input a number :\n");
	scanf("%s",str);

	printf("The original system is : \n");
	scanf("%d",&n);

	printf("The decimal system of the number is : %d\n",Get_Number(str,n));
}

int Get_Number(char Str[], int N)
{
	int num = 0,len = strlen(Str),i = 0;

	while(len--)
	{
		num += (Str[i++] - '0') * pow((double)N,len);
	}
	
	return num;
}