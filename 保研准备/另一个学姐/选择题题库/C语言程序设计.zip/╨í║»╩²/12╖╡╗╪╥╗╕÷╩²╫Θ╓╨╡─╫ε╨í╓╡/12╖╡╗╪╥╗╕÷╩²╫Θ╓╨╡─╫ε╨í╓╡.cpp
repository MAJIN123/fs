//����һ�������е���Сֵ

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int Min_of_Array(int*, int);

void main()
{
	int arr[20],i;

	printf("The 20 numbers are:\n");
	
	srand(time(NULL));
	for(i = 0;i < 20;i++)
	{
		arr[i] = rand() % 1000;
		printf("%-5d",arr[i]);

		if ((i+1) % 10 == 0)
		{
			printf("\n");
		}
	}

	printf("The minimum number is : %d\n",Min_of_Array(arr,20));
}

int Min_of_Array(int Arr[],int N)
{
	int min = 1000,i;

	for(i = 0;i < N;i++)
	{
		min = min < Arr[i]?min:Arr[i];
	}

	return min;
}