//����һ���ַ����ַ����г��ֵĴ���

#include <stdio.h>

int Get_App_Num(char*, char);

void main()
{
	char str[1001],c;

	printf("Please input a string:\n");
	gets(str);

	printf("Please input a letter:\n");
	scanf("%c",&c);

	printf("%c appears %d times in the string.\n",c,Get_App_Num(str,c));
}

int Get_App_Num(char Str[], char C)
{
	int cnt = 0,i = 0;

	while(Str[i] != '\0')
	{
		if (Str[i++] == C)
		{
			cnt++;
		}
	}

	return cnt;
}