//����һ�������е����ֵ����Сֵ��ƽ��ֵ

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void Arr_Count(int arr[], int n, int *max, int *min, double *avg);

void main()
{
	int arr[20],i;
	int max,min;
	double avg;

	printf("The 20 numbers are:\n");
	
	srand(time(NULL));
	for(i = 0;i < 20;i++)
	{
		arr[i] = rand() % 1000;
		printf("%-5d",arr[i]);

		if ((i+1) % 10 == 0)
		{
			printf("\n");
		}
	}
	
	Arr_Count(arr,20,&max,&min,&avg);

	printf("The maximum number is : %d\n",max);
	printf("The minimum number is : %d\n",min);
	printf("The average of the numbers is : %.2lf\n",avg);
}

void Arr_Count(int Arr[], int N, int *Max, int *Min, double *Avg)
{
	int sum = 0,i;

	*Max = 0;
	*Min = 1000;

	for(i = 0;i < N;i++)
	{
		*Max = *Max > Arr[i]?*Max:Arr[i];
		*Min = *Min < Arr[i]?*Min:Arr[i];
		sum += Arr[i];
	}

	*Avg = sum / (double)N;
}