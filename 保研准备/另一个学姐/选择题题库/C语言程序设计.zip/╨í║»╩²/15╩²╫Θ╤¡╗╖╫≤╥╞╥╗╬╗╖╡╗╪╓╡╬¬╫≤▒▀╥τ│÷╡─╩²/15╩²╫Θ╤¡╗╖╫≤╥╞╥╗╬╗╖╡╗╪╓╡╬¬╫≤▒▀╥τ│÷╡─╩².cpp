//����ѭ������һλ����ֵΪ����������

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int Array_Shift_Left(int*, int);

void main()
{
	int arr[20],i;

	printf("The original array is:\n");
	srand(time(NULL));
	for(i = 0;i < 20;i++)
	{
		arr[i] = rand() % 1000;
		printf("%-5d",arr[i]);

		if ((i+1) % 10 == 0)
		{
			printf("\n");
		}
	}
	if (i % 10 != 0)
	{
		printf("\n");
	}
	printf("\n");

	arr[19] = Array_Shift_Left(arr,20);

	printf("The new array is:\n");
	for(i = 0;i < 20;i++)
	{
		printf("%-5d",arr[i]);

		if ((i+1) % 10 == 0)
		{
			printf("\n");
		}
	}
	if (i % 10 != 0)
	{
		printf("\n");
	}
}

int Array_Shift_Left(int Arr[], int N)
{
	int tmp = Arr[0],i;

	for(i = 0;i < N-1;i++)
	{
		Arr[i] = Arr[i+1];
	}

	return tmp;
}