//һά��������

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int *sort(int*,int);

void main()
{
	int n,i;

	printf("Please input how many numbers do you want to sort\n");
	scanf("%d",&n);

	int *p = (int*)malloc(sizeof(int)*n);

	srand(time(NULL));
	for(i = 0;i < n;i++)
	{
		p[i] = rand() % 1000;
	}

	int *c = *sort(int*,int);
	free(p);
}