//����һ���ַ����д�д��ĸ��Сд��ĸ�����ַ����ֵĴ���

#include <stdio.h>

void Str_Count(char*,int*,int*,int*);

void main()
{
	char str[1001];
	int small = 0,capital = 0,digital = 0;

	printf("Please input a string:\n");
	gets(str);

	Str_Count(str,&small,&capital,&digital);

	printf("Small appear %d times in the string.\n",small);
	printf("Capital appear %d times in the string.\n",capital);
	printf("Digital appear %d times in the string.\n",digital);
}

void Str_Count(char Str[], int *Small, int *Capital, int *Digital)
{
	int i = 0;

	while(Str[i] != '\0')
	{
		if (Str[i] >= '0' && Str[i] <= '9')
		{
			(*Digital)++;
		}
		else
		{
			if (Str[i] >= 'a' && Str[i] <= 'z')
			{
				(*Small)++;
			}
			else
			{
				if (Str[i] >= 'A' && Str[i] <= 'Z')
				{
					(*Capital)++;
				}
			}
		}
		i++;
	}
}