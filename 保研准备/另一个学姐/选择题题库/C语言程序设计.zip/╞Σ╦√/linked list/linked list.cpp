//�����Ĵ������ͷţ���ӡ�����ң�ɾ���Ͳ���

#include <stdio.h>
#include <stdlib.h>

typedef struct Node
{
	int Score;

	Node *Next;
}Node;

Node* func_CreateList();
Node* func_FreeList(Node*);
void func_DisplayList(Node*,int);
Node* func_FindNode(Node*,int);
Node* func_DeleteNode(Node*,int,int*);
Node* func_InsertNode(Node*,int,int,int*);

void main()
{
	Node *head;
	int flag = 1;
	int score,new_score;

	printf("����������\n");
	head = func_CreateList();

	printf("��ʾ������\n");
	func_DisplayList(head,flag);

	printf("��������Ҫɾ���ķ�����\n");
	scanf("%d",&score);
	head = func_DeleteNode(head,score,&flag);
	func_DisplayList(head,flag);

	printf("��������Ҫ��������һ��������ǰ���Ҫ����ķ�����\n");
	scanf("%d%d",&score,&new_score);
	head = func_InsertNode(head,score,new_score,&flag);
	func_DisplayList(head,flag);

	head = func_FreeList(head);
}

Node* func_CreateList()
{
	Node *head;
	Node *p,*q;
	int tmp;

	head = (Node*)malloc(sizeof(Node));
	q = head;

	while(1)
	{
		scanf("%d",&tmp);
		if (tmp == -9999)
		{
			break;
		}
		
		p = (Node*)malloc(sizeof(Node));
		q->Next = p;
		p->Score = tmp;
		q = p;
	}
	q->Next = NULL;

	return head;
}

Node* func_FreeList(Node* Head)
{
	Node *p,*q;

	q = Head;
	while(q != NULL)
	{
		p = q->Next;
		free(q);
		q = p;
	}

	return NULL;
}

void func_DisplayList(Node *Head,int Flag)
{
	Node *p;
	int cnt = 0;

	if (Flag == 0)
	{
		printf("û���ҵ�������֡�\n");
	}
	else
	{
		p = Head->Next;
		while(p != NULL)
		{
			printf("%-5d",p->Score);
			p = p->Next;

			cnt++;
			if (0 == cnt % 10)
			{
				printf("\n");
			}
		}
		if (0 != cnt % 10)
		{
			printf("\n");
		}
	}
}

Node* func_FindNode(Node *Head,int Score)
{
	Node *p,*q;

	q = Head;
	p = q->Next;
	while(p != NULL)
	{
		if (p->Score == Score)
		{
			return q;
		}

		q = p;
		p = p->Next;
	}

	return NULL;
}

Node* func_DeleteNode(Node *Head,int Score,int *Flag)
{
	Node *p,*q;

	q = func_FindNode(Head,Score);

	if (q == NULL)
	{
		*Flag = 0;
		return Head;
	}
	else
	{
		p = q->Next;
		q->Next = p->Next;
		free(p);

		*Flag = 1;
		return Head;
	}
}

Node* func_InsertNode(Node *Head,int Score,int New_Score,int *Flag)
{
	Node *p,*q;

	q = func_FindNode(Head,Score);

	if (q == NULL)
	{
		*Flag = 0;
		return Head;
	}
	else
	{
		p = (Node*)malloc(sizeof(Node));
		p->Next = q->Next;
		q->Next = p;
		p->Score = New_Score;

		*Flag = 1;
		return Head;
	}
	return Head;
}