#include <stdio.h>
#include <string.h>
#define N 10001
void main(){
	int len1,len2,i,j,num[N],flag = 0;
	char str1[N],str2[N],s1[N],s2[N];
	scanf("%s%s",str1,str2);
	if (strlen(str1) > strlen(str2)){
		strcpy(s1,str2);
		strcpy(s2,str1);
		len1 = strlen(str2);
		len2 = strlen(str1);
	}
	else{
		strcpy(s1,str1);
		strcpy(s2,str2);
		len1 = strlen(str1);
		len2 = strlen(str2);
	}
	for(i = 0;i < len2;i++){
		if (i < len1){
			num[i] = (s1[len1-1-i] + s2[len2-1-i] - 2 * '0' + flag) % 10;
			if (s1[len1-1-i] + s2[len2-1-i] + flag - 2 * '0' > 9) flag = 1;
			else flag = 0;
		}
		else{
			num[i] = (s2[len2-1-i] - '0' + flag) % 10;
			flag = (s2[len2-1-i] - '0' + flag) / 10;
		}
	}
	if ((len1 == len2 && flag == 1) || (len2 - len1 >= 1 && s2[0] == '9' && flag == 1)) num[i++] = 1;
	for(j = 0;j < i;j++) printf("%d",num[i-1-j]);
}
