#include <stdio.h>
#include <string.h>
//int arr(int,int);
void main()
{
	char str[1001];
	gets(str);
	printf("%d",strlen(str));
	
}

/*int arr(int x,int y)
{
	return x>y?x:y;
}*/