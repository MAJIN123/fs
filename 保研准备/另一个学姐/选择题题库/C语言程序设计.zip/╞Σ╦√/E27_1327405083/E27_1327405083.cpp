//cut a sentence into words and print them

#include <stdio.h>
void main()
{
	int cnt = 0;                                                 //define the variables for counter and string
	char str[1001];

	printf("Please input a sentence:\n");                        //input a sentence
	gets(str);

	while(str[cnt] != '\0')                                      //judge whether the string is over
	{
		if(str[cnt] == ' ' || str[cnt] == ',' || str[cnt] == ';' || str[cnt] == '.')         //control every word a line
		{
			printf("\n");
			cnt++;
		}
		else
		{
			printf("%c",str[cnt++]);                              //print every word
		}
	}

	printf("\n");
}