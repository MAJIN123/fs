//�ı��ļ����������ļ�

/*//�ı��ļ�
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int Input_Array(int*, int);
int Write_Text_File(char*, int Array[], int);
int Read_Text_File(char*, int*, int*);
void Display_Array(int*, int);

void main()
{
	int num[100],cpy_num[101];          //����ԭ����
	int cnt,cpy_cnt;
	int res;
	char fname[100];

	cnt = Input_Array(num,100);

	printf("����д����ļ�����");
	scanf("%s",fname);
	strcat(fname,".dat");

	res = Write_Text_File(fname,num,cnt);
	if (0 == res)
	{
		printf("���ļ�ʧ��.\n");
		return;
	}

	res = Read_Text_File(fname,cpy_num,&cpy_cnt);
	if (0 == res)
	{
		printf("���ļ�ʧ��.\n");
		return;
	}

	Display_Array(cpy_num,cpy_cnt);

}

int Input_Array(int Array[], int Cnt)
{
	int i;
	int tmp;

	for(i = 0;i < Cnt;i++)
	{
		scanf("%d",&tmp);

		if (-9999 == tmp)
		{
			break;
		}
		Array[i] = tmp;
	}

	return i;
}

int Write_Text_File(char FName[], int Array[], int Cnt)
{
	FILE *fp;
	int i;

	fp = fopen(FName,"w");
	if (fp == NULL)
	{
		return 0;
	}

	for(i = 0;i < Cnt;i++)
	{
		fprintf(fp,"%-10d",Array[i]);

		if ((i+1) % 5 == 0)
		{
			fprintf(fp,"\n");
		}
	}
	if (i % 5 != 0)
	{
		fprintf(fp,"\n");
	}

	fclose(fp);
	return 1;
}

int Read_Text_File(char FName[], int Array[], int *Cnt)
{
	FILE *fp;
	int i,res;

	fp = fopen(FName,"r");
	if (fp == NULL)
	{
		return 0;
	}

	i = 0;
	while(!feof(fp))
	{
		res = fscanf(fp,"%d",&Array[i++]);

		if (res == -1)
		{
			i--;
		}
	}
	*Cnt = i;
	
	fclose(fp);
	return 1;
}

void Display_Array(int Array[], int Cnt)
{
	int i;

	for(i = 0;i < Cnt;i++)
	{
		printf("%-10d",Array[i]);

		if ((i+1) % 5 == 0)
		{
			printf("\n");
		}
	}
	if (i % 5 != 0)
	{
		printf("\n");
	}
}*/


//�������ļ�
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int Input_Array(int*,int);
int Write_Text(char*,int*,int);
int Read_Text(char*,int*,int*);
void Display_Text(int*,int);


void main()
{
	int cnt,cpy_cnt;
	int num[100],cpy_num[100];
	int res;
	char fname[101];

	cnt = Input_Array(num,100);

	printf("������Ҫд����ļ�����");
	scanf("%s",fname);
	strcat(fname,".txt");

	res = Write_Text(fname,num,cnt);

	if(0 == res)
	{
		printf("�޷�������ļ�\n");
		return;
	}
	
	res = Read_Text(fname,cpy_num,&cpy_cnt);
	if (0 == res)
	{
		printf("�޷�������ļ�\n");
		return;
	}

	Display_Text(cpy_num,cpy_cnt);
}

int Input_Array(int Array[], int Cnt)
{
	int i;
	int tmp;
	FILE *fp;

	for(i = 0;i < Cnt;i++)
	{
		scanf("%d",&tmp);

		if (-9999 == tmp)
		{
			break;
		}

		Array[i] = tmp;
	}

	return i;
}

int Write_Text(char FName[], int Array[], int Cnt)
{
	int i;
	FILE *fp;

	fp = fopen(FName,"wb");
	if (fp == NULL)
	{
		return 0;
	}

	fwrite(Array,sizeof(int),Cnt,fp);

	fclose(fp);
	return 1;
}

/*int Read_Text(char FName[], int Array[], int *Cnt)
{
	int i;
	int res;
	FILE *fp;

	fp = fopen(FName,"rb");
	if (fp == NULL)
	{
		return 0;
	}

	i = 0;
	while(!feof(fp))
	{
		res = fread(&Array[i++],sizeof(int),1,fp);
		
		if (0 == res)
		{
			i--;
		}
	}

	*Cnt = i;
	fclose(fp);
	return 1;
}*/

int Read_Text(char FName[], int Array[], int *Cnt)
{
	FILE *fp;

	fp = fopen(FName,"rb");
	if (fp == NULL)
	{
		return 0;
	}

	fseek(fp,0,2);
	*Cnt = ftell(fp)/sizeof(int);
	rewind(fp);
	fread(Array,sizeof(int),*Cnt,fp);

	fclose(fp);
	return 1;
}

void Display_Text(int Array[], int Cnt)
{
	int i;

	for(i = 0;i < Cnt;i++)
	{
		printf("%-10d",Array[i]);

		if (0 == (i+1) % 5)
		{
			printf("\n");
		}
	}
	if (0 != i % 5)
	{
		printf("\n");
	}
}