//�����е�note��Ϊnode������

#include <stdio.h>
#include <stdlib.h>

struct Note
{
	int Score;

	struct Note *Next;
};

struct Note* func_CreateList();
void func_DisplayList(struct Note*);
struct Note* func_InsertNote(struct Note*,int,int,int*);
struct Note* func_DeleteNote(struct Note*,int,int*);
struct Note* func_FindNote(struct Note*,int);
void func_Display_NewList(struct Note*,int);
struct Note* func_FreeList(struct Note*);

void main()
{
	int score,new_score,flag;
	struct Note *head;

	printf("����������\n");
	head = func_CreateList();

	printf("��ӡ������\n");
	func_DisplayList(head);

	printf("�����³ɼ���score,new_score\n");
	scanf("%d%d",&score,&new_score);
	head = func_InsertNote(head,score,new_score,&flag);
	func_Display_NewList(head,flag);

	printf("Ҫɾ���ĳɼ���\n");
	scanf("%d",&score);
	head = func_DeleteNote(head,score,&flag);
	func_Display_NewList(head,flag);

	head = func_FreeList(head);
}

struct Note* func_CreateList()
{
	struct Note *p,*q;
	struct Note *head;
	int tmp;

	head = (struct Note*)malloc(sizeof(struct Note));
	q = head;

	while(1)
	{
		scanf("%d",&tmp);
		if (tmp == -9999)
		{
			break;
		}

		p = (struct Note*)malloc(sizeof(struct Note));
		p->Score = tmp;
		q->Next = p;
		q = p;
	}
	q->Next = NULL;

	return head;
}

void func_DisplayList(struct Note *Head)
{
	struct Note *p;
	int cnt = 0;

	p = Head->Next;

	while(p != NULL)
	{
		printf("%-5d",p->Score);
		p = p->Next;

		cnt++;
		if (cnt % 10 == 0)
		{
			printf("\n");
		}
	}

	if (cnt % 10 != 0)
	{
		printf("\n");
	}
}

struct Note* func_InsertNote(struct Note *Head,int Score,int New_Score,int *Flag)
{
	struct Note *p,*q;

	q = func_FindNote(Head,Score);

	if (q == NULL)
	{
		*Flag = 0;
		return Head;
	}

	p = (struct Note*)malloc(sizeof(struct Note));
	p->Score = New_Score;

	p->Next = q->Next;
	q->Next = p;

	*Flag = 1;
	return Head;
}

struct Note* func_DeleteNote(struct Note *Head,int Score,int *Flag)
{
	struct Note *p,*q;

	q = func_FindNote(Head,Score);

	if (q == NULL)
	{
		*Flag = 0;
		return Head;
	}

	p = q->Next;
	q->Next = p->Next;
	free(p);

	*Flag = 1;
	return Head;
}

struct Note* func_FindNote(struct Note *Head,int Score)
{
	struct Note *p,*q;

	q = Head;
	p = q->Next;

	while(p != NULL)
	{
		if (p->Score == Score)
		{
			return q;
		}

		q = p;
		p = p->Next;
	}

	return NULL;
}

void func_Display_NewList(struct Note *Head,int Flag)
{
	if (Flag)
	{
		printf("�µ�����Ϊ��\n");
		func_DisplayList(Head);
	}
	else
	{
		printf("û���ҵ���Ӧ�ĳɼ���\n");
	}
}

struct Note* func_FreeList(struct Note *Head)
{
	struct Note *p,*q;

	q = Head;
	
	while(q != NULL)
	{
		p = q->Next;
		free(q);
		q = p;
	}

	return NULL;
}