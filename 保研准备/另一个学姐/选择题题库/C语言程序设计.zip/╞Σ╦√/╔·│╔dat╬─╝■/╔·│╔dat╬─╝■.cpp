#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 20

int main()
{
	FILE *fp;
	int i;
	int tmp;

	fp = fopen("file.dat","wb");

	srand(time(NULL));

	for(i = 0;i < N;i++)
	{
		tmp = rand() % 10000;
		fprintf(fp,"%-10d",tmp);
		if ((i+1) % 5 == 0) fprintf(fp,"\n");
	}
	if (i % 5 != 0) fprintf(fp,"\n");

	return 0;
}