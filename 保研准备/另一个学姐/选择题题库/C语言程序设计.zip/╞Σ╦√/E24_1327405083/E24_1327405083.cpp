//print n*n magical square

#include<stdio.h>
void main()
{
	int n = 3,row,column,arr[3][3]={8,1,6,3,5,7,4,9,2},sum[8] = {},judge = 1,acc = 1;
	
/*	for(row = 0;row < n;row++)
	{
		for(column = 0;column < n;column++)
		{
			arr[row][column] = acc++;
		}
	}*/

	while(judge)
	{
		judge = 1;
		for(row = 0;row < n;row++)
		{
			for(column = 0;column < n;column++)
			{
				sum[row] += arr[row][column];
			}
			if(row > 0)
			{
				if(sum[row] != sum[row-1])
				{
					break;
				}
				else
				{
					judge++;
				}
			}

			if(judge == n)
			{
				for(column = 0;column < n;column++)
				{
					for(row = 0;row < n;row++)
					{
						sum[column+3] += arr[row][column];
					}
					if(sum[column+3] != sum[column+3-1])
					{
						break;
					}
					else
					{
						judge++;
					}
				}
			}
			if(judge == n * 2)
			{
				for(row = 0;row < n;row++)
				{
					sum[2*n] += arr[row][row];
					sum[2*n+1] += arr[row][n-1-row];
				}
				if(sum[2*n] == sum[2*n+1] && sum[2*n] == sum[2*n-1])
				{
					judge = 0;
				}
			}
		}

exchange

	}

	for(row = 0;row < n;row++)
	{
		for(column = 0;column < n;column++)
		{
			printf("%-5d",arr[row][column]);
		}
		printf("\n");
	}
}