#include <stdio.h>
void main()
{
	int m = 5;
	if(m++ > 5) printf("%d",m);
	else printf("%d",m++);
}