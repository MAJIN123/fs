//����

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Worker
{
		int num;				//����
		char name[10];		    //����
		int  age;			    //����
		int  sex;				//�Ա�0-��  1-Ů��
		float salary;			//����
}WORKER;

typedef struct worker_node
{
	WORKER Data;

	struct worker_node *Next;
}NODE;

NODE* func_ReadFile();
void func_FreeList(NODE*);
void func_Display(NODE*);
void func_Sort(NODE*);
void func_Delete(NODE*);
void func_Insert(NODE*);
void func_Analy(NODE*,double*,int*);
void func_WriteFile(NODE*);

void main()
{
	NODE *head;
	double aver_salary;
	int max_age;

	head = func_ReadFile();
	printf("�ļ���ȡ��Ϻ������Ϊ:\n");
	func_Display(head);

	func_Sort(head);
	printf("������Ϻ������Ϊ:\n");
	func_Display(head);

	func_Delete(head);
	printf("��������ɾ����Ϻ������Ϊ:\n");
	func_Display(head);

	func_Insert(head);
	printf("�����½��������Ϊ:\n");
	func_Display(head);

	func_Analy(head, &aver_salary, &max_age);
	printf("%10.2f%10d\n",aver_salary,max_age);

	func_WriteFile(head);

	func_FreeList(head);
}

NODE* func_ReadFile()
{
	FILE *fp;
	NODE *head;
	NODE *p,*q;
	WORKER tmp;

	fp = fopen("D:\\C���Գ������\\��ĩ��ϰ\\����\\Source1.dat", "rb");
	if (fp==NULL)
	{
		printf("�ļ�����ʧ��!\n");
		exit(0);
	}

	head = (NODE*)malloc(sizeof(NODE));
	q = head;

	while (!feof(fp))
	{
		if (0 != fread(&tmp,sizeof(WORKER),1,fp))
		{
			p = (NODE*)malloc(sizeof(NODE));
			p->Data = tmp;
			q->Next = p;
			q = p;
		}
	}
	q->Next = NULL;

	fclose(fp);

	return head;
}

void func_FreeList(NODE *Head)
{
	NODE *p,*q;

	q = Head;
	while (NULL != q)
	{
		p = q->Next;
		free(q);
		q = p;

	}
}

void func_Display(NODE *Head)
{
	NODE *p;
	char buf[10];

	p=Head->Next;
	while(p!=NULL)
	{
		if (p->Data.sex == 0)
		{
			strcpy(buf,"��");
		}
		else
		{
			strcpy(buf,"Ů");
		}
		printf("%5d%20s%5d%5s%10.2f\n",p->Data.num, p->Data.name,p->Data.age, buf, p->Data.salary);

		p=p->Next;
	}
}

void func_Sort(NODE *Head)
{
	NODE *p,*q;
	NODE *tail;

	tail = NULL;
	while (tail != Head->Next)
	{
		q = Head;
		p = q->Next;
		while (tail != p->Next)
		{
			if (q->Next->Data.num > p->Next->Data.num)
			{
				q->Next = p->Next;
				p->Next = p->Next->Next;
				q->Next->Next = p;
			}

			q = q->Next;
			p = q->Next;
		}
		tail = p;
	}
}

void func_Delete(NODE *Head)
{
	NODE *p,*q;

	q = Head;
	p = q->Next;

	while (NULL != p)
	{
		if ((p->Data.sex==0 && p->Data.age<40) || (p->Data.sex==1 && p->Data.num>650))
		{
			q->Next = p->Next;
			free(p);
			p = q->Next;
		}
		else
		{
			q = q->Next;
			p = p->Next;
		}
	}
}

void func_Insert(NODE *Head)
{
	FILE *fp;
	NODE *q,*p;
	WORKER tmp;

	fp = fopen("D:\\C���Գ������\\��ĩ��ϰ\\����\\Source2.dat", "rb");
	if (fp==NULL)
	{
		printf("�ļ�����ʧ��!\n");
		exit(0);
	}

	while(!feof(fp))
	{
		if (0 != fread(&tmp,sizeof(WORKER),1,fp))
		{
			p = (NODE*)malloc(sizeof(NODE));
			p->Data = tmp;
			q = Head;
			while(NULL != q->Next)
			{
				if (tmp.num < q->Next->Data.num)
				{
					p->Next = q->Next;
					q->Next = p;
					break;
				}
				q = q->Next;
			}
			if (NULL == q->Next)
			{
				q->Next = p;
				p->Next = NULL;
			}
		}
	}

	fclose(fp);
}

void func_Analy(NODE *Head,double *Aver_Salary,int *Max_Age)
{
	NODE *p;
	double sum=0.0;
	int count=0,max=-1;
	
	p = Head->Next;
	while (NULL != p)
	{
		if(p->Data.sex==0 && p->Data.age > 30)
		{
			sum+=p->Data.salary;
			count++;
		}

		if(p->Data.sex==1 && p->Data.salary < 3000)
		{
			if (max<p->Data.age)
			{
				max = p->Data.age;
			}
		}
		p=p->Next;
	}

	*Aver_Salary = sum/count;
	*Max_Age = max;
}

void func_WriteFile(NODE *Head)
{
	FILE *fp;
	NODE *p;
	char buf[10];

	fp = fopen("D:\\C���Գ������\\��ĩ��ϰ\\����\\res.txt","w");
	if(fp==NULL)
	{
		printf("�޷����ļ�\n");
		exit(0);
	}

	p=Head->Next;
	while(p!=NULL)
	{
		if (p->Data.sex == 0)
		{
			strcpy(buf,"��");
		}
		else
		{
			strcpy(buf,"Ů");
		}
		fprintf(fp,"%5d%20s%5d%5s%10.2f\n",p->Data.num, p->Data.name,p->Data.age, buf, p->Data.salary);

		p=p->Next;
	}
	
	fclose(fp);
}