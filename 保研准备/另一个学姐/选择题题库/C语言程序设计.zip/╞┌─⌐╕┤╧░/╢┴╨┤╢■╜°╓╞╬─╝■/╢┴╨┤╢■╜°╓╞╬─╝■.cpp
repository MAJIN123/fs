//��д�������ļ�

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int Input_Array(int*,int);
int Write_Dat(char*,int*,int);
int Read_Dat(char*,int*,int*);
void Display(int*,int);

void main()
{
	char fname[101];
	int num[100],num_cpy[100];
	int res;
	int cnt,cnt_cpy;

	printf("���������������100������-9999������\n");
	cnt = Input_Array(num,100);

	printf("��������Ҫд��������ļ�����\n");
	scanf("%s",fname);
	strcat(fname,".dat");
	res = Write_Dat(fname,num,cnt);
	if (0 == res) return;

	res = Read_Dat(fname,num_cpy,&cnt_cpy);
	if (0 == res) return;

	Display(num_cpy,cnt_cpy);
}

int Input_Array(int *Arr,int N)
{
	int i;
	int tmp;

	for(i = 0;i < N;i++)
	{
		scanf("%d",&tmp);

		if (-9999 == tmp) break;

		Arr[i] = tmp;
	}

	return i;
}

int Write_Dat(char *FName,int *Arr,int N)
{
	FILE *fp;

	fp = fopen(FName,"wb");
	if (NULL == fp) return 0;

	fwrite(Arr,sizeof(int),N,fp);

	fclose(fp);
	return 1;
}

/*int Read_Dat(char *FName,int *Arr,int *Cnt)
{
	FILE *fp;
	int i;
	int res;

	fp = fopen(FName,"rb");
	if (NULL == fp) return 0;

	i = 0;
	while(!feof(fp))
	{
		res = fread(&Arr[i++],sizeof(int),1,fp);

		if (0 == res) i--;
	}

	*Cnt = i;
	fclose(fp);
	return 1;
}*/

int Read_Dat(char *FName,int *Arr,int *Cnt)
{
	FILE *fp;

	fp = fopen(FName,"rb");
	if (NULL == fp) return 0;

	fseek(fp,0,2);
	*Cnt = ftell(fp)/sizeof(int);
	rewind(fp);
	fread(Arr,sizeof(int),*Cnt,fp);

	fclose(fp);
	return 1;
}

void Display(int *Arr,int N)
{
	int i;

	for(i = 0;i < N;i++)
	{
		printf("%d",Arr[i]);

		if ((i+1) % 5 == 0) printf("\n");
	}
	if (i % 5 != 0) printf("\n");
}