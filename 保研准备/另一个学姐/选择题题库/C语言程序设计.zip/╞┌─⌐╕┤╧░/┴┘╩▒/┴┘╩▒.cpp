#include <stdio.h>

/*void main()                                  //++��=�����㼶
{
int i = 0;
int j = 0;

while(i++ != 5)
{
j++;
}

printf("i = %d,j = %d",i,j);
}*/

/*#include <stdlib.h>
#include <time.h>

#define N 5

void main()                                                     //����realloc������
{
int *p = (int*)malloc(sizeof(int)*N);

int i;

srand(time(NULL));
for(i = 0;i < N;i++)
{
*(p+i) = rand()%1000;
printf("%-5d",*(p+i));
}
printf("\n");

int *q = (int*)realloc(p,sizeof(int)*(N-2));

for(i = 0;i < N-2;i++)
{
printf("%-5d",*(q+i));
}
printf("\n");

for(i = 0;i < N;i++)
{
printf("%-5d",*(q+i));
}
printf("\n");
}*/

/*int func();                            //���ڷ���ֵ�ĸ�ʽ����

void main()
{
printf("%d\n",func());
}

int func()
{
int i = 2;
int j = 3;

return i>j?i:j;
}*/

/*int Binary(int,int*);

void main()
{
int n;
int cnt;
int arr[100];
int i;

scanf("%d",&n);

cnt = Binary(n,arr);
for(i = 0;i < cnt;i++)
{
printf("%d\n",arr[i]);
}
}

int Binary(int n,int *arr)
{
int mod;
int cnt;

cnt = 0;
if (n < 2)
{
arr[cnt++] = n;

return cnt;
}
else
{
mod = n % 2;
cnt = Binary(n/2,arr);
arr[cnt++] = mod;

return cnt;
}
}*/

/*void func(int*);

void main()
{
int arr[3][4];

func(arr);
}

void func(int arr[3][4])
{
}

void func(int arr[][4])
{
}

void func(int arr[3][])//��
{
}

void func(int arr[][])//��
{
}*/

/*int i;                        //ȫ�ֱ���ֻ�Զ���һ�µ����������ã�����ĺ����ò���

void func()
{
i = 0;
j = 0;
}

int j;

void main()
{
i = 0;
j = 0;
}*/

/*#include <stdlib.h>
#include <time.h>

#define N 10                              //����ͽ����ð������

void Sort_up(int*);
void Sort_down(int*);
void Display(int*);

void main()
{
int i,j;
int arr_up[N],arr_down[N];

srand(time(NULL));
for(i = 0;i < N;i++)
{
arr_up[i] = rand()%1000;
arr_down[i] = arr_up[i];
}

Sort_up(arr_up);
printf("�������У�\n");
Display(arr_up);

printf("-------------------------------------\n");

Sort_down(arr_down);
printf("��������\n");
Display(arr_down);
}

void Display(int *arr)
{
int i;

for(i = 0;i < N;i++)
{
printf("%-5d",arr[i]);
}
printf("\n");
}

void Sort_down(int *arr)
{
int i,j;
int t;

for(i = 0;i < N-1;i++)
for(j = 0;j < N-1-i;j++)
{
if (arr[j] < arr[j+1])
{
t = arr[j];
arr[j] = arr[j+1];
arr[j+1] = t;
}
}
}

void Sort_up(int *arr)
{
int i,j;
int t;

for(i = 0;i < N-1;i++)
for(j = 0;j < N-1-i;j++)
{
if (arr[j] > arr[j+1])
{
t = arr[j];
arr[j] = arr[j+1];
arr[j+1] = t;
}
}
}*/

/*void main()
{
char *s;
s = "I'm happy!";
printf("%s\n",s);
}*/

/*void main()                         //�޷������Ϳ���%uҲ��%d
{
unsigned int a;

scanf("%d",&a);
printf("%d\n",a);

scanf("%u",&a);
printf("%d\n",a);

printf("%u\n",-32768);//��
}*/

/*void main()                             //char���͸�ֵ
{
char c = 97;

printf("%d\n",c);
printf("%c\n",c);
}*/

/*void main()
{
long int a = 5;

printf("%d\n",a);
printf("%ld\n",a);
}*/

/*void main()                                //i+++j == (i++)+j
{
int i = 2;
int j = 3;
int t;

t = i+++j;

printf("i = %d\n",i);
printf("j = %d\n",j);
printf("%d\n",t);
}*/

/*void main()
{
//	double a,b,c,d;
float a,b,c,d;//�����doubleһ��

a = 5 / 3;                          //1.000000
b = 5.0 / 3;                        //1.666667
c = 5 / 3.0;                        //1.666667
//	d = (double)(5 / 3);                //1.000000
d = float(5 / 3);

printf("%.6lf\n",a);
printf("%.6lf\n",b);
printf("%.6lf\n",b);
printf("%.6lf\n",d);

printf("\n");

printf("%d\n",a);//0
printf("%d\n",b);//-......
printf("%d\n",b);//-......
printf("%d\n",d);//0

printf("\n");

printf("%.6f\n",a);//����lfһ��
printf("%.6f\n",b);//
printf("%.6f\n",b);//
printf("%.6f\n",d);//
}*/

/*void main()
{
double a = 5;
printf("%lf\n",a/3);//1.66...7

double b = 3;
printf("%lf\n",5/b);//1.66...7
}*/

/*#include <math.h>

void main()                         //sqrt   pow
{
int a,b;

a = sqrt(4.0);//2
b = pow(2,3.0);//8

printf("%d\n%d\n",a,b);
}*/

/*void main()
{
double pi = 3.1415926;                          //%(+)/(-)/()m.n����

printf("%-10.5lf\n",pi);//3.14159
printf("%10.5lf\n",pi);//   3.141592
printf("%+10.5lf\n",pi);//  +3.14159

printf("%+10.5lf\n",-pi);//  -3.14159
}*/

/*void main()                                          //%e
{
double pi = 3141.5926;
int a = 5;
double b = 5.0;

printf("%e\n",pi);//3.141593e+003
printf("%e\n",a);//����                              //������λ����
printf("%e\n",b);//5.000000e+000
}*/

/*void main()                                   //%llf
{
long double a = 1;

printf("%llf\n",a);
}*/

/*#include <stdlib.h>                     //��������

//ð��
struct node
{
	int i;
	node* pnode;
}NODE;


NODE* bubblesort(NODE *head)
{
	NODE *q,*tail,*p=(NODE*)malloc(sizeof(NODE));
	p->next = head;
	head = p;
	tail = NULL;
	while(tail != head->next)
	{
		p = head;
		q =p->next;
		while(q->next != tail)
		{
			if (p->next->i < q->next->i)
			{
				p->next = q->next;
				q->next = q->next->next;
				p->next->next = q;
			}
			p = p->next;
			q = p->next;
		}
		tail = q;
	}
	p = head->next;
	free(head);
	return p;
}*/

//2:��������
/*struct LIST
{
	int i;
	LIST* next;
}NODE;

LIST qsortL (LIST h, LIST lnext)
{
	NODE n1, n2;
	LIST p, t1 = &n1, t2 = &n2;
	if (h == NULL) return lnext;
	for (p = h->next; p != NULL;
		p = p->next)
		if (p->i < h->i)
		{
			t1->next = p;
			t1 = p;
		}
		else
		{
			t2->next = p;
			t2 = p;
		}
		t1->next = t2->next = NULL;
		h->next = qsortL(n2.next, lnext);
		return qsortL(n1.next, h);
} */

/*void main()
{
	int a;

	a = 3 * (a = 2); //û�У����Ǵ���
	printf("%d\n",a);
}*/

/*void main()
{
	printf("%d\n",(NULL == 0));//1
}*/

#include <stdio.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

void* produce(char, int);
void orderify(char, void *, int);
void exchange(char, void *, void *);
void print(char, void *, int);

int main(int argc,char *argv[])

{

  int n = 0;
  char a;
  void *p = NULL;

  if(strcmp(argv[2], "int") == 0)
  {
    a = 'i';
  }
  else
  {
    a = 'd';
  }
printf("%c \n", a);
  
  n = atoi(argv[1]);
  p = produce(a,n);
  orderify(a,p,n);
  print(a,p,n);
  
  free(p);
return 0;  
}



void* produce(char a,int n)
{
  
  int *pi = NULL;
  double *pd = NULL;
  int i = 0;
printf("n = %d\n", n);
  switch(a)
  {
    case 'i':
    pi = (int *)malloc(sizeof(int) * n);
    srand(time(NULL));
    for(i = 0;i < n;i++)
    {
      *(pi + i) = rand()%1000;
      printf("%d  ",*(pi + i));
    }
    printf("\n");
    return (void *)pi;
    break;
    case 'd':
    pd = (double *)malloc(sizeof(double) * n);
    srand(time(NULL));
    for(i = 0;i < n;i++)
    {
      *(pd + i) = (rand()%100000)/100.0;
      printf("%lf  ",*(pd + i));
    }
    printf("\n");
    return (void*)pd;
    break;
  }
  
}



void orderify(char a,void * b,int n)
{
  int i = 0,j = 0;
  switch(a)
  {
    case 'i':
      for(i = n;i > 1;--i)
      {
        for (j = 0;j < i - 1;++j)
        {
          if(*((int*)b + j) < *((int*)b + j + 1))
          {
            exchange(a,(int*)b + j,(int*)b + j + 1);
          }
        }
      }
      break;
    case 'd':
      for(i = n;i > 1;--i)
      {
        for (j = 0;j < i - 1;++j)
        {
          if(*((double*)b + j) < *((double*)b + j + 1))
          {
            exchange(a,(double*)b + j,(double*)b + j + 1);
          }
        }
      }
      break;
  }
}



void print(char a,void *b,int n)
{
  int i = 0;
  for(i = 0;i < n;++i)
  {
    switch(a)
    {
      case 'i':
      printf("%d  ",*((int*)b + i));
      break;
      case 'd':
      printf("%lf  ",*((double*)b +i));
      break;
    }
  }
  printf("\n");
}



void exchange(char a,void *i,void *j)
{
  int k;
  double m;
  switch(a)
  {
    case 'i':
      k = *((int*)i);
      *((int*)i) = *((int*)j);
      *((int*)j) = k;
      break;
    case 'd':
      m = *((double*)i);
      *((double*)i) = *((double*)j);
      *((double*)j) = m;
      break;
  }

  return;
}

