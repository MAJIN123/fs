//�书

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct person
{
	char name[20];		    //����
	int  sex;				//�Ա���Ϊ0��ŮΪ1
	int  kongfu;			//�书
	int  flightPerformance; //�Ṧ
}PERSON;

int Read_File(PERSON*);
void Display(PERSON);
PERSON Find_Min(PERSON*,int);
void Sort(PERSON*,int);
int Delete(PERSON*,int);
void Write_File(PERSON*,int);

void main()
{
	PERSON arr[20];
	PERSON tmp;
	int cnt;
	int i;

	cnt = Read_File(arr);
	printf("�����˵���ϢΪ��\n");
	for(i = 0;i < cnt;i++)
	{
		Display(arr[i]);
	}

	tmp = Find_Min(arr,cnt);
	printf("�Ṧ���书����С�����ǣ�\n");
	Display(tmp);

	Sort(arr,cnt);
	printf("�����Ľ��Ϊ��\n");
	for(i = 0;i < cnt;i++)
	{
		Display(arr[i]);
	}

	cnt = Delete(arr,cnt);
	printf("ɾ����Ľ��Ϊ��\n");
	for(i = 0;i < cnt;i++)
	{
		Display(arr[i]);
	}

	Write_File(arr,cnt);
}

int Read_File(PERSON *Arr)
{
	FILE *fp;
	int cnt;
	char name[101] = "D:\\C���Գ������\\��ĩ��ϰ\\�书\\input.dat";

	fp = fopen(name,"rb");
	if (NULL == fp)
	{
		printf("�޷��򿪴��ļ���\n");
		exit(0);
	}

	fseek(fp,0,2);
	cnt = ftell(fp)/sizeof(PERSON);
	rewind(fp);
	fread(Arr,sizeof(PERSON),cnt,fp);

	fclose(fp);

	return cnt;
}

void Display(PERSON Data)
{
	char ch[10];

	if (0 == Data.sex)
	{
		strcpy(ch,"��");
	}
	else
	{
		strcpy(ch,"Ů");
	}
	//������ռ10������롿���Ա�ռ5���Ҷ��롿���书ռ4���Ҷ��롿���Ṧռ4���Ҷ��롿
	printf("%-10s%5s%4d%4d\n",Data.name, ch, Data.kongfu, Data.flightPerformance);
}

PERSON Find_Min(PERSON *Arr,int N)
{
	int i;
	int min_inx;

	min_inx = 0;
	for(i = 1;i < N;i++)
	{
		if (Arr[i].kongfu+Arr[i].flightPerformance < Arr[min_inx].kongfu+Arr[min_inx].flightPerformance)
		{
			min_inx = i;
		}
	}

	return Arr[min_inx];
}

void Sort(PERSON *Arr,int N)
{
	int i,j;
	int max_inx;
	PERSON tmp;

	for(i = 0;i < N-1;i++)
	{
		max_inx = i;
		for(j = i+1;j < N;j++)
		{
			if (Arr[max_inx].sex < Arr[j].sex)
			{
				max_inx = j;
			}
		}
		if (i != max_inx)
		{
			tmp = Arr[max_inx];
			Arr[max_inx] = Arr[i];
			Arr[i] = tmp;
		}
	}

	for(i = 0;i < N-1;i++)
	{
		max_inx = i;
		for(j = i+1;j < N;j++)
		{
			if (Arr[max_inx].flightPerformance < Arr[j].flightPerformance)
			{
				max_inx = j;
			}
		}
		if (i != max_inx)
		{
			tmp = Arr[max_inx];
			Arr[max_inx] = Arr[i];
			Arr[i] = tmp;
		}
	}
}

int Delete(PERSON *Arr,int N)
{
	int i,j;

	for(i = 0;i < N;i++)
	{
		if (Arr[i].flightPerformance == Arr[i].kongfu)
		{
			for(j = i;j < N-1;j++)
			{
				Arr[j] = Arr[j+1];
			}

			i--;
			N--;
		}
	}

	return N;
}

void Write_File(PERSON *Arr,int N)
{
	FILE *fp;

	char name[101] = "D:\\C���Գ������\\��ĩ��ϰ\\�书\\output.dat";

	fp = fopen(name,"wb");
	if (NULL == fp)
	{
		printf("�޷��򿪴��ļ���\n");
		exit(0);
	}

	fwrite(Arr,sizeof(PERSON),N,fp);

	fclose(fp);

}