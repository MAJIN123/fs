//�书LinkedList

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct person
{
	char name[20];		    //����
	int  sex;				//�Ա���Ϊ0��ŮΪ1
	int  kongfu;			//�书
	int  flightPerformance; //�Ṧ
}PERSON;

typedef struct person_node
{
	PERSON Data;

	struct person_node *Next;
}NODE;

NODE* func_CreateList();
void func_FreeList(NODE*);
void DisplayList(NODE*);
void Display(PERSON);
PERSON func_FindMin(NODE*);
void Sort(NODE*);
void func_Delete(NODE*);
void Write_File(NODE*);

void main()
{
	NODE *head;
	PERSON min;

	head = func_CreateList();
	printf("��ȡ����ϢΪ��\n");
	DisplayList(head);

	min = func_FindMin(head);
	printf("�Ṧ���书����С��Ϊ��\n");
	Display(min);

	Sort(head);
	printf("����Ľ��Ϊ��\n");
	DisplayList(head);

	func_Delete(head);
	printf("ɾ����Ľ���ǣ�\n");
	DisplayList(head);

	Write_File(head);

	func_FreeList(head);
}

NODE* func_CreateList()
{
	NODE *head;
	NODE *p,*q;
	PERSON tmp;
	FILE *fp;
	char name[101] = "D:\\C���Գ������\\��ĩ��ϰ\\�书LinkedList\\input.dat";

	fp = fopen(name,"rb");
	if (NULL == fp)
	{
		printf("�޷��򿪴��ļ���\n");
		exit(0);
	}

	head = (NODE*)malloc(sizeof(NODE));
	q = head;
	while (!feof(fp))
	{
		if (0 != fread(&tmp,sizeof(PERSON),1,fp))
		{
			p = (NODE*)malloc(sizeof(NODE));
			p->Data = tmp;

			q->Next = p;
			q = p;
		}
	}
	q->Next = NULL;

	fclose(fp);

	return head;
}

void func_FreeList(NODE *Head)
{
	NODE *p,*q;

	q = Head;
	while (NULL != q->Next)
	{
		p = q->Next;
		free(q);
		q = p;
	}
}

void DisplayList(NODE *Head)
{
	NODE *p;

	p = Head->Next;
	while (NULL != p)
	{
		Display(p->Data);
		p = p->Next;
	}
}

void Display(PERSON Data)
{
	char ch[10];

	if (0 == Data.sex)
	{
		strcpy(ch,"��");
	}
	else
	{
		strcpy(ch,"Ů");
	}
	//������ռ10������롿���Ա�ռ5���Ҷ��롿���书ռ4���Ҷ��롿���Ṧռ4���Ҷ��롿
	printf("%-10s%5s%4d%4d\n",Data.name, ch, Data.kongfu, Data.flightPerformance);
}

PERSON func_FindMin(NODE *Head)
{
	NODE *p;
	int min_inx;
	PERSON min_data;

	p = Head->Next;
	min_inx = 201;
	while (NULL != p)
	{
		if (min_inx > p->Data.flightPerformance+p->Data.kongfu)
		{
			min_inx = p->Data.flightPerformance+p->Data.kongfu;
			min_data = p->Data;
		}

		p = p->Next;
	}

	return min_data;
}

void Sort(NODE *Head)
{
	NODE *p,*q;
	NODE *tail;

	tail = NULL;
	while(tail != Head->Next)
	{
		q = Head;
		p = q->Next;

		while (tail != p->Next)
		{
			if (q->Next->Data.flightPerformance < p->Next->Data.flightPerformance)
			{
				q->Next = p->Next;
				p->Next = p->Next->Next;
				q->Next->Next = p;
			}

			q = q->Next;
			p = q->Next;
		}
		tail = p;
	}
}

void func_Delete(NODE *Head)
{
	NODE *p,*q;

	q = Head;
	while (NULL != q->Next)
	{
		p = q->Next;
		if (p->Data.flightPerformance == p->Data.kongfu)
		{
			q->Next = p->Next;
			free(p);
			continue;
		}
		q = q->Next;
	}
}

void Write_File(NODE *Head)
{
	FILE *fp;
	NODE *p;

	char name[101] = "D:\\C���Գ������\\��ĩ��ϰ\\�书LinkedList\\output.dat";

	fp = fopen(name,"wb");
	if (NULL == fp)
	{
		printf("�޷��򿪴��ļ���\n");
		exit(0);
	}

	p = Head->Next;
	while (NULL != p)
	{
		fwrite(&p->Data,sizeof(PERSON),1,fp);
		p = p->Next;
	}

	fclose(fp);

}