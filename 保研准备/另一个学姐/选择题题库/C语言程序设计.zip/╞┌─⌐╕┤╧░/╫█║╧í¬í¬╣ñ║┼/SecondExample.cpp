#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Worker
{
		int num;				//����
		char name[10];		//����
		int  age;			//����
		int  sex;				//�Ա�0-��  1-Ů��
		float salary;			//����
}WORKER;

typedef struct Worker_Node
{
		WORKER Data;
		struct Worker_Node *Next;
}WORKER_NODE;

WORKER_NODE* ReadFile();
void FreeList(WORKER_NODE *Head);
void DisplayList(WORKER_NODE *Head);
void Sort(WORKER_NODE *Head);
void DeleteNode(WORKER_NODE *Head);
void InsertNode(WORKER_NODE *Head);
void AnalyData(WORKER_NODE *Head, double *AverSalary, int *MaxAge);
void WriteFile(WORKER_NODE *Head);

void main()
{
	WORKER_NODE *head;
	double aver_salary;
	int max_age;

	head = ReadFile();
	printf("�ļ���ȡ��Ϻ������Ϊ:\n");
	DisplayList(head);

	Sort(head);
	printf("������Ϻ������Ϊ:\n");
	DisplayList(head);

	DeleteNode(head);
	printf("��������ɾ����Ϻ������Ϊ:\n");
	DisplayList(head);

	InsertNode(head);
	printf("�����½��������Ϊ:\n");
	DisplayList(head);

	AnalyData(head, &aver_salary, &max_age);
	printf("%10.2f%10d\n",aver_salary,max_age);

	WriteFile(head);

	FreeList(head);
}

WORKER_NODE* ReadFile()
{
	FILE *fp;
	WORKER_NODE *p,*q, *head;
	WORKER temp;

	fp = fopen("c:\\Source1.dat", "rb");
	if (fp==NULL)
	{
		printf("�ļ�����ʧ��!\n");
		exit(0);
	}

	head = (WORKER_NODE*)malloc(sizeof(WORKER_NODE));
	q=head;
	while(!feof(fp))
	{
		if (fread(&temp,sizeof(WORKER),1,fp) != 0)
		{
			p = (WORKER_NODE*)malloc(sizeof(WORKER_NODE));
			p->Data = temp;
			q->Next = p;
			q = p;
		}
	}
	q->Next=NULL;

	fclose(fp);

	return head;
}

void FreeList(WORKER_NODE *Head)
{
	WORKER_NODE *p,*q;

	q=Head;
	while (q!=NULL)
	{
		p=q->Next;
		free(q);
		q=p;
	}
}

void DisplayList(WORKER_NODE *Head)
{
	WORKER_NODE *p;
	char buf[10];

	p=Head->Next;
	while(p!=NULL)
	{
		if (p->Data.sex == 0)
		{
			strcpy(buf,"��");
		}
		else
		{
			strcpy(buf,"Ů");
		}
		printf("%5d%20s%5d%5s%10.2f\n",p->Data.num, p->Data.name,
			p->Data.age, buf, p->Data.salary);

		p=p->Next;
	}
}

void Sort(WORKER_NODE *Head)
{
	WORKER_NODE *p1, *p2, *min_node, *q1, *q2;
	WORKER temp;

	p1=Head->Next;

	if (p1==NULL || p1->Next==NULL)
	{
		return;
	}

	while( p1->Next->Next != NULL)
	{
		min_node = p1;

		p2=p1->Next;
		while(p2!=NULL)
		{
			if (p2->Data.num < min_node->Data.num)
			{
				min_node = p2;
			}

			p2=p2->Next;
		}
		if (min_node != p1)
		{
			temp = min_node->Data;
			min_node->Data = p1->Data;
			p1->Data = temp;
		}

		p1=p1->Next;
	}
}

void DeleteNode(WORKER_NODE *Head)
{
	WORKER_NODE *p,*q;

	q=Head;
	p=Head->Next;

	while(p!=NULL)
	{
		if ( (p->Data.sex==0 && p->Data.age<40) || (p->Data.sex==1 && p->Data.num>650) )
		{
			q->Next = p->Next;
			free(p);
			p=q->Next;
		}
		else
		{
			q=p;
			p=p->Next;
		}
	}
}

void InsertNode(WORKER_NODE *Head)
{
	FILE *fp;
	WORKER_NODE *p,*q;
	WORKER temp;

	fp = fopen("c:\\Source2.dat", "rb");
	if (fp==NULL)
	{
		printf("�ļ�����ʧ��!\n");
		exit(0);
	}

	while(!feof(fp))
	{
		if (fread(&temp,sizeof(WORKER),1,fp) != 0)
		{
			p = (WORKER_NODE*)malloc(sizeof(WORKER_NODE));
			p->Data = temp;

			q=Head;
			while (q->Next !=NULL)
			{
				if (temp.num < q->Next->Data.num)
				{
					p->Next = q->Next;
					q->Next = p;
					break;
				}

				q=q->Next;
			}
			if(q->Next == NULL)
			{
				p->Next = NULL;
				q->Next = p;				
			}
		}
	}

	fclose(fp);
}

void AnalyData(WORKER_NODE *Head, double *AverSalary, int *MaxAge)
{
	WORKER_NODE *p;
	double sum=0.0;
	int count=0,max=-1;

	p=Head->Next;
	while(p != NULL)
	{
		if(p->Data.sex==0 && p->Data.age > 30)
		{
			sum+=p->Data.salary;
			count++;
		}

		if(p->Data.sex==1 && p->Data.salary < 3000)
		{
			if (max<p->Data.age)
			{
				max = p->Data.age;
			}
		}
		p=p->Next;
	}

	*AverSalary = sum/count;
	*MaxAge = max;
}

void WriteFile(WORKER_NODE *Head)
{
	FILE *fp;
	WORKER_NODE *p;
	char buf[10];

	fp = fopen("c:\\res.txt","w");
	if(fp==NULL)
	{
		printf("ŷ��\n");
		exit(0);
	}

	p=Head->Next;
	while(p!=NULL)
	{
		if (p->Data.sex == 0)
		{
			strcpy(buf,"��");
		}
		else
		{
			strcpy(buf,"Ů");
		}
		fprintf(fp,"%5d%20s%5d%5s%10.2f\n",p->Data.num, p->Data.name,
			p->Data.age, buf, p->Data.salary);

		p=p->Next;
	}
	
	fclose(fp);
}