#include<stdio.h>
#include<math.h>
#include<malloc.h>

struct node
{
    int value;
    struct node *next;
};
typedef struct node NODE;

#define LEN sizeof(NODE)

NODE *create( int ia[], int n );
void display( NODE *p );
void release( NODE *p );
void insert_by_order( NODE *h, NODE *p );
void order( NODE *p );

int main()
{
    int a[] = { 17, 5, 5, 7, 11, 13, 2, 29, -100 };
    NODE *head;

    head = create( a, sizeof( a ) / sizeof( int ) );
    order( head );
    display( head );
    release( head );
    return 0;
}

NODE *create( int ia[], int n )
{
    NODE *h, *p1;
    int i;

    h = ( NODE * ) malloc( LEN );
    h->value = -1;
    h->next = NULL;

    for ( i = 0; i < n; i++ )
    {
        p1 = ( NODE * )malloc( LEN );
        p1->value = ia[i];
        p1->next = h->next;
        h->next = p1;
    }

    return h;
}

void display( NODE *p )
{
    while ( p != NULL )
    {
        printf( "%d\n", p->value );
        p = p->next;
    }

    return;
}

void release( NODE *p )
{
    NODE *q;

    while ( p != NULL )
    {
        q = p;
        p = p->next;
        free( q );
    }

    return;
}

// insert by order
void insert_by_order( NODE *h, NODE *p )
{
    NODE *q;

    q = h;

    while ( q->next != NULL && p->value > q->next->value )
    {
        q = q->next;
    }

    p->next = q->next;
    q->next = p;
    return;
}

// sorting
void order( NODE *h )
{
    NODE *q, *move;

    if ( h == NULL ) { return; }

    move = h->next;
    h->next = NULL;

    while ( move != NULL )
    {
        q = move;
        move = move->next;
        insert_by_order( h, q );
    }

    return;
}


