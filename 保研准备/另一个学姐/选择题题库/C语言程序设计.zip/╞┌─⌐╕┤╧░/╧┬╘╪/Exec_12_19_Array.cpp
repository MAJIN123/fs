#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct person
{
	char name[20];		//����
	int  sex;				//�Ա���Ϊ0��ŮΪ1
	int  kongfu;			//�书
	int  flightPerformance; //�Ṧ
}PERSON;

int ReadFile(PERSON *Arr);
void Display(PERSON Data);
PERSON FindMinPerson(PERSON Arr[], int Count);
void Sort(PERSON *Arr, int Count);
void ChildSort(PERSON *Arr,  int Count);
void Delete(PERSON *Arr,  int *Count);
void WriteFile(PERSON *Arr,  int Count);

void main()
{
	PERSON a[20], temp;
	int count, i;

	count = ReadFile(a);
	printf("�ļ���ȡ�����������Ϊ:\n");
	for(i=0;i<count;i++)
	{
		Display(a[i]);
	}

	temp = FindMinPerson(a,count);
	printf("\n�书���Ṧ����С����Ϊ:\n");
	Display(temp);

	Sort(a,count);
	printf("\n��������������Ϊ:\n");
	for(i=0;i<count;i++)
	{
		Display(a[i]);
	}

	Delete(a, &count);
	printf("\n����ɾ�������������Ϊ:\n");
	for(i=0;i<count;i++)
	{
		Display(a[i]);
	}

	WriteFile(a,count);
}

int ReadFile(PERSON *Arr)
{
	FILE *fp;
	int count;

	fp=fopen("C:\\input.dat","rb");
	if (fp==NULL)
	{
		exit(0);
	}

	fseek(fp,0,2);
	count = ftell(fp)/sizeof(PERSON);
	rewind(fp);
	fread(Arr,sizeof(PERSON),count,fp);

	fclose(fp);

	return count;
}

void Display(PERSON Data)
{
	char buf[10];

	//������ռ10������롿���Ա�ռ5���Ҷ��롿���书ռ4���Ҷ��롿���Ṧռ4���Ҷ��롿
	if(Data.sex==0)
	{
		strcpy(buf,"��");
	}
	else
	{
		strcpy(buf,"Ů");
	}
	printf("%-10s%5s%4d%4d\n",Data.name, buf, Data.kongfu, Data.flightPerformance);
}

PERSON FindMinPerson(PERSON Arr[], int Count)
{
	int min_inx=0, i;

	for(i=1;i<Count;i++)
	{
		if ( (Arr[min_inx].kongfu+Arr[min_inx].flightPerformance) > (Arr[i].kongfu+Arr[i].flightPerformance) )
		{
			min_inx = i;
		}
	}

	return Arr[min_inx];
}

void Sort(PERSON *Arr, int Count)
{
	int i,j,max_inx, start, end;
	PERSON temp;

	for(i=0;i<Count-1;i++)
	{
		max_inx=i;
		for(j=i+1;j<Count;j++)
		{
			if (Arr[max_inx].flightPerformance < Arr[j].flightPerformance)
			{
				max_inx = j;
			}
		}

		if(max_inx != i)
		{
			temp = Arr[i];
			Arr[i]=Arr[max_inx];
			Arr[max_inx]=temp;
		}
	}

	start=0;
	for(i=1;i<Count;i++)
	{
		if (Arr[i-1].flightPerformance == Arr[i].flightPerformance)
		{
			continue;
		}
		else
		{
			if (start == i-1)
			{
				start = i;
				continue;
			}
			else
			{
				end = i-1;
				ChildSort(Arr+start, end-start+1);
				start=i;
			}
		}
	}
	if (start != Count-1)
	{
		end = Count-1;
		ChildSort(Arr+start, end-start+1);
	}
}

void ChildSort(PERSON *Arr,  int Count)
{
	int i,j,max_inx, start, end;
	PERSON temp;

	for(i=0;i<Count-1;i++)
	{
		max_inx=i;
		for(j=i+1;j<Count;j++)
		{
			if (Arr[max_inx].sex < Arr[j].sex)
			{
				max_inx = j;
			}
		}

		if(max_inx != i)
		{
			temp = Arr[i];
			Arr[i]=Arr[max_inx];
			Arr[max_inx]=temp;
		}
	}
}

void Delete(PERSON *Arr,  int *Count)
{
	int t,i,j;

	t=*Count;

	for(i=0;i<t;i++)
	{
		if (Arr[i].flightPerformance == Arr[i].kongfu)
		{
			for(j=i+1;j<t;j++)
			{
				Arr[j-1]=Arr[j];
			}
			t--;
			i--;
		}
	}
	*Count=t;
}

void WriteFile(PERSON *Arr,  int Count)
{
	int i;
	FILE *fp;
	char buf[10];

	fp=fopen("C:\\out.txt","w");
	if (fp==NULL)
	{
		printf("out.txt�ļ�д������ʧ��!\n");
		exit(0);
	}

	for(i=0;i<Count;i++)
	{
		if(Arr[i].sex==0)
		{
			strcpy(buf,"��");
		}
		else
		{
			strcpy(buf,"Ů");
		}	
		fprintf(fp,"%-10s%5s%4d%4d\n",Arr[i].name, buf, Arr[i].kongfu, Arr[i].flightPerformance);
	}
	fclose(fp);	
}

