#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct person
{
	char name[20];		//����
	int  sex;				//�Ա���Ϊ0��ŮΪ1
	int  kongfu;			//�书
	int  flightPerformance; //�Ṧ
}PERSON;

typedef struct person_node
{
	PERSON Data;

	struct person_node *Next;
}PERSON_NODE;

PERSON_NODE* CreateList();
void FreeList(PERSON_NODE *Head);
void Display(PERSON Data);
void DisplayList(PERSON_NODE *Head);

void main()
{
	PERSON_NODE *head;

	head = CreateList();

	printf("�ļ���ȡ��ɺ������Ϊ:\n");
	DisplayList(head);

	FreeList(head);
}

PERSON_NODE* CreateList()
{
	FILE *fp;
	PERSON_NODE *p,*q,*head;
	int i, count;
	PERSON temp;
	
	fp=fopen("C:\\input.dat","rb");
	if (fp==NULL)
	{
		exit(0);
	}

	head = (PERSON_NODE*)malloc(sizeof(PERSON_NODE));
	q=head;

	while (!feof(fp))
	{
		if (fread(&temp, sizeof(PERSON),1,fp) != 0)
		{
			p = (PERSON_NODE*)malloc(sizeof(PERSON_NODE));
			p->Data = temp;

			q->Next = p;
			q=p;
		}
	}
	q->Next = NULL;

/*
	fseek(fp,0,2);
	count = ftell(fp)/sizeof(PERSON);
	rewind(fp);

	for(i=0;i<count;i++)
	{
		fread(&temp, sizeof(PERSON),1,fp);
		p = (PERSON_NODE*)malloc(sizeof(PERSON_NODE));
		p->Data = temp;

		q->Next = p;
		q=p;
	}
	q->Next=NULL;
*/

	fclose(fp);

	return head;
}

void FreeList(PERSON_NODE *Head)
{
	PERSON_NODE *q, *p;

	q=Head;
	while(q!=NULL)
	{
		p=q->Next;
		free(q);
		q=p;
	}
}

void DisplayList(PERSON_NODE *Head)
{
	PERSON_NODE *p;

	p=Head->Next;
	while(p!=NULL)
	{
		Display(p->Data);
		p=p->Next;
	}
}

void Display(PERSON Data)
{
	char buf[10];

	//������ռ10������롿���Ա�ռ5���Ҷ��롿���书ռ4���Ҷ��롿���Ṧռ4���Ҷ��롿
	if(Data.sex==0)
	{
		strcpy(buf,"��");
	}
	else
	{
		strcpy(buf,"Ů");
	}
	printf("%-10s%5s%4d%4d\n",Data.name, buf, Data.kongfu, Data.flightPerformance);
}