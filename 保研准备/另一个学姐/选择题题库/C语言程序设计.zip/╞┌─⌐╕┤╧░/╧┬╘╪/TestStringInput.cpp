#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void main()
{
	int a,b;
	char s1[100],s2[100],s3[100],s4[100],temp[3];

	scanf("%d",&a);
	scanf("%d",&b);
	temp[0]=getchar();

	gets(s1);
	temp[1]=getchar();
	gets(s2);

	scanf("%s",s3);
	temp[2]=getchar();
	scanf("%s",s4);

	return;
}
