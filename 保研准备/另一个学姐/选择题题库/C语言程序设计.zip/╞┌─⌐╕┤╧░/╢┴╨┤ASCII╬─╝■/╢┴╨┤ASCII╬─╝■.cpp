//��дASCII�ļ�

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int Input_Array(int*,int);
int Write_Text(char*,int*,int);
int Read_Text(char*,int*,int*);
void Display(int*,int);

void main()
{
	int num[100],num_cpy[100];
	char fname[101];
	int cnt,cnt_cpy;
	int res;

	printf("���������������100������-9999������\n");
	cnt = Input_Array(num,100);

	printf("������Ҫд����ļ�����\n");
	scanf("%s",fname);
	strcat(fname,".txt");
	res = Write_Text(fname,num,cnt);
	if (0 == res)
	{
		printf("�޷��򿪴��ļ���\n");
		return;
	}

	res = Read_Text(fname,num_cpy,&cnt_cpy);
	if (0 == res)
	{
		printf("�޷��򿪴��ļ���\n");
		return;
	}

	Display(num_cpy,cnt_cpy);
}

int Input_Array(int *Arr,int N)
{
	int i;
	int tmp;

	scanf("%d",&tmp);
	for(i = 0;i < N;i++)
	{
		if (-9999 == tmp) break;
		
		Arr[i] = tmp;
		
		scanf("%d",&tmp);
	}

	return i;
}

int Write_Text(char *Fname,int *Arr,int N)
{
	FILE *fp;
	int i;

	fp = fopen(Fname,"w");
	if (NULL == fp) return 0;

	for(i = 0;i < N;i++)
	{
		fprintf(fp,"%-10d",Arr[i]);

		if ((i+1) % 5 == 0) fprintf(fp,"\n");
	}

	fclose(fp);
	return 1;
}

int Read_Text(char *Fname,int *Arr,int *Cnt)
{
	FILE *fp;
	int i;
	int res;

	fp = fopen(Fname,"r");
	if (NULL == fp) return 0;

	i = 0;
	while (!feof(fp))
	{
		res = fscanf(fp,"%d",&Arr[i++]);

		if (-1 == res) i--;
	}

	*Cnt = i;
	fclose(fp);
	return 1;
}

void Display(int *Arr,int N)
{
	int i;

	for(i = 0;i < N;i++)
	{
		printf("%-10d",Arr[i]);

		if ((i+1) % 5 == 0) printf("\n");
	}
	if (i % 5 != 0) printf("\n");
}