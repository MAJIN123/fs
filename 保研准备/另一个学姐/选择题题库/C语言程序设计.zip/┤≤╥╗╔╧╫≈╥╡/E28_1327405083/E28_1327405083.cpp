//use function to calculate the greatest common divisor and the lowest common multiply of two numbers

#include <stdio.h>

int func_GCD(int,int);                                    //define two functions for calculate the greatest common divisor and the lowest common multiply
int func_LCM(int,int,int);

void main()
{
	int a,b,gcd,lcm;                                       //define the variables for two numbers and the greatest common divisor and the lowest common multiply

	printf("Please input two numbers:\n");         //input two numbers
	scanf("%d%d",&a,&b);

	gcd = func_GCD(a,b);                               //call functions to calculate
	lcm = func_LCM(a,b,gcd);

	printf("The grestest common divisor of the the two numbers is:\n%d\nThe lowest common multiple of the two numbers is:\n%d\n",gcd,lcm);
	                                                            //print the greatest common divisor and the lowest common multiply of the two numbers
}                                                                                

int func_GCD(int A,int B)
{
	int m = A < B ? A:B;                                 //define m to be the lower number of A and B
	
	while(1)
	{
		if(A % m == 0 && B % m == 0)               //find out the greatest common divisor of the two number
		{
			return m;
		}
		else
		{
			m--;
		}
	}
}

int func_LCM(int A,int B,int GCD)                     //calculate the lowest common mutiply of the two numbers
{
	return (A * B / GCD);
}