#include <stdio.h>
#include <malloc.h>
void main()
{
	int n,i,**arr,row,column,cnt = 1;                                      //define the variables for circulate,storage and counter

	printf("Please input an odd number(>=3) to decide how large the magical square is:\n");
	scanf("%d",&n);                                                        //decide how large the magical square is

	arr = (int**)malloc(sizeof(int) * n);                                  //apply space for array and initialize the array
	for(i = 0;i < n;i++)
	{
		arr[i] = (int*)malloc(sizeof(int) * n);
	}
	for(row = 0;row < n;row++)
	{
		for(column = 0;column < n;column++)
		{
			arr[row][column] = 0;
		}
	}

	for(row = 0,column = (n-1)/2;cnt <= n * n;cnt++)                       //put the numbers in the magical square
	{
		arr[row][column] = cnt;

		row = (row + n - 1) % n;
		column = (column + 1) % n;

		if(arr[row][column] != 0)
		{
			row = (row + 2) % n;
			column = (column + n -1) % n;
		}
	}

	printf("\n\n%d * %d magical square are:\n\n",n,n);                      //print the magical square
	for(row = 0;row < n;row++)
	{
		for(column = 0;column < n;column++)
		{
			printf("%-4d",arr[row][column]);
		}
		printf("\n\n\n");
	}

	free(arr);                                                             //release the space arr
}