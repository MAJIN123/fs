//�ж�һ���ַ����Ƿ����

#include <stdio.h>
#include <string.h>

int func_HuiWen(char*);                   //declare the function to judge whether the string is HuiWen

void main()
{
	char str[1001];

	printf("Please input a string:\n");   //input a string
	scanf("%s",str);

	if(func_HuiWen(str))                  //print the result
	{
		printf("Ture\n");
	}
	else
	{
		printf("False\n");
	}
}

int func_HuiWen(char Str[])
{
	int len = strlen(Str),i = 0,j;

	for(i = 0;i < len;i++)                //exclude the characters which are not alphabet
	{
		if(Str[i] < 'A' || (Str[i] > 'Z' && Str[i] < 'a') || Str[i] > 'z')
		{
			for(j = i;j < len;j++)
			{
				Str[j] = Str[j+1];
			}
			i--;
			len--;
		}
	}

	i = 0;
	while(i < len-i-1)                    //judge whether the string is a Hui Wen
	{
		if (Str[i] != Str[len-i-1])
		{
			return 0;                     //the string is not Hui Wen
		}
		else
		{
			i++;
		}
	}

	return 1;                             //the sting is Hui Wen
}