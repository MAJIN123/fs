#include <stdio.h>
void main()
{
	int i,m,n,maxys,minbs;                                         //define the variables

	printf("please input two numbers\n");                          //input the datas
	scanf("%d%d",&m,&n);

	if(m>n)                                                        //calculate the zui da gong yue shu
	{
		i = m;
		m = n;
		n = i;
	}
	for(i = 1;i <= m;i++)
	{
		if(m % i == 0 && n % i == 0)
		{
			maxys = i;
		}
	}
	minbs = m * n / maxys;                                          //calculate the zui xiao gong bei shu

	printf("������������С������Ϊ%d\n�������������Լ��Ϊ%d\n",minbs,maxys);            //output the result
}