//use piont to tranform a decimal number into a binary number

#include <stdio.h>

int func_Binary(int*,int);                             //declare the function to transform a decimal number into a binary number

void main()
{
	int n,cnt,arr[1000],i;                             //define the variables:n for storing the decimal number,arr for storing the binary number
	                                                   //cnt for calculating how long the binary number is,i for circulating 

	printf("Please input a number:\n");                //input a decimal number
	scanf("%d",&n);

	cnt = func_Binary(arr,n);                          //call the function to transform and return the length of the binary number

	for(i = 0;i < cnt;i++)                             //print the number by binary system
	{
		printf("%-2d",arr[i]);
	}
	printf("\n");
}

int func_Binary(int Arr[],int n)
{
	int cnt = 0,mod;                                   //cnt is for calculating how long the binary number is,mod for storing the mod

	if (n <= 1)                                        //give the condition to stop the recursion
	{
		Arr[cnt++] = n;
		return cnt;                                    //return the length of the binary number
	}
	else
	{
		mod = n % 2;
		cnt = func_Binary(Arr,n/2);                     //use recursion to transform the decimal number
		Arr[cnt++] = mod;                               //store 1 or 0 and add up cnt for calculate the length of the binary number
		
		return cnt;                                     //return the temporary length of the binary number
	}
}