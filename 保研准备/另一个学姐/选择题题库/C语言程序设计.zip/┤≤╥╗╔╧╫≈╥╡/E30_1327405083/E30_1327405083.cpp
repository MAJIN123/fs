//sort 20 random numbers and print them

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void sort();
void print();

void main()
{
	int arr[20],i;

	srand(time(NULL));
	
	for(i = 0;i < 20;i++)
	{
		arr[i] = rand() % 1000;
	}

	sort(arr);

	print(arr);
}

void sort(int Arr[20])
{
	int i,j,temp;
	
	for(i = 0;i < 18;i++)
	{
		for(j = i+1;j < 19;j++)
		{
			temp = Arr[j];
			Arr[j] = Arr[j+1];
			Arr[j+1] = temp;
		}
	}
}

void print(int Arr[20])
{
	int i;
	
	for(i = 0;i < 20;i++)
	{
		printf("%-3d",Arr[i]);

		if((i+1) % 5 == 0)
		{
			printf("\n");
		}
	}
}
