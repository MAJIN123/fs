//copy a file

#include <stdio.h>
#include <stdlib.h>

void main()
{
	FILE *fp,*cpy_fp;                                           //two pointers point to the two files
	char ch,filename[2][10],str[2][10] = {"original","copied"}; //array filename[] is to store the names of the two files
	int i;                                                      //i is for circlulate

	for(i = 0;i < 2;i++)                                        //input the names of the two files
	{
		printf("Please input the %s filename:",str[i]);
		scanf("%s",filename[i]);
	}

	if ((fp = fopen(filename[0],"r")) == NULL)                  //judge whether the two files can be found
	{
		printf("Sorry!The file didn't exist.\n");
		exit(0);
	}
	if ((cpy_fp = fopen(filename[1],"w")) == NULL)
	{
		printf("Sorry!The file didn't exist.\n");
		exit(0);
	}

	while(!feof(fp))                                            //copy the original file and display the copied file
	{
		ch = fgetc(fp);
		fputc(ch,cpy_fp);
		putchar(ch);
	}
	fputc('#',cpy_fp);
	printf("\n");

	fclose(fp);                                                 //close the files
	fclose(cpy_fp);
}