//print a string in inverted order

#include <stdio.h>
#include <string.h>
void main()
{
	char str1[101],str2[101];                                         //define the variables for store the strings,circulate and calculate the length of the original string
	int length,i;

	printf("Please input a string:\n");                               //input a string
	scanf("%s",str1);

	length = strlen(str1);                                            //reform the string by inverted order
	for(i = 0;i < length;i++)
	{
		str2[i] = str1[length - 1 - i];
	}
	str2[length] = '\0';

	printf("The inverted order of the string is:\n%s\n",str2);        //print the new string
}