//calculate how many days between two dates

#include <stdio.h>

struct Date
{
	int year;
	int month;
	int day;
};

int func_nDays(struct Date*);                                                                      //declare the function to calculate how many days between the two dates

void main()
{
	struct Date date[2];
	int i;

	for(i = 0;i < 2;i++)                                                                           //input the year,month and day of the dates
	{
		printf("Please input the year,month and day of Date%d:\n",i+1);
		scanf("%d%d%d",&date[i].year,&date[i].month,&date[i].day);
	}

	printf("There are %d days between the two dates.\n",func_nDays(date));                         //print how many days between the two dates
}

int func_nDays(struct Date Date[])
{
	int days[2] = {};                                                                              //array days is for storing the days that year
	int month_day[12] = {0,31,28,31,30,31,30,31,31,30,31,30};                                      //how many days in which month
	int leap_year_cnt = 0;                                                                         //leap_year_cnt is for counter how many leap years between the two years
	int is_leap_year[2];                                                                           //array is_leap_year is for storing the result of the judge whether Date.year[i] is a leap year
	int flag_400;                                                                                  //flag_400 is for considering the condition that there is a year % 400 = 0 between the two years
	int dyear;                                                                                     //dyear is how many years between the two years
	int i,j;                                                                                       //i,j are for circulating
	struct Date tmp;                                                                               //tmp is a temporary variable for exchanging two struct Date

	if (Date[0].year < Date[1].year)                                                               //let the latter year store into the Date[0]
	{
		tmp = Date[0];
		Date[0] = Date[1];
		Date[1] = tmp;
	}

	for(i = 0;i < 2;i++)                                                                           //judge whether the two years are leap years//1 is yes and 0 is no
	{
		if (Date[1].year % 400 == 0)
		{
			is_leap_year[i] = 1;
		}
		else
		{
			if (Date[1].year % 100 != 0 && Date[1].year % 4 == 0)
			{
				is_leap_year[i] = 1;
			}
			else
			{
				is_leap_year[i] = 0;
			}
		}
	}

	for(i = 0;i < 2;i++)                                                                           //calculate how many days in that year
	{
		for(j = 0;j < Date[i].month;j++)
		{
			days[i] += month_day[j];
		}
		days[i] += Date[i].day;
		if (Date[i].month > 2 && is_leap_year)
		{
			days[i]++;
		}
	}

	if (dyear = Date[0].year - Date[1].year)                                                       //if the two dates aren't in the same year
	{
		if ((Date[0].year /100) != (Date[1].year /100))                                            //consider the condition that whether there has a year % 400 = 0
		{                                                                                          //flag_400 = how many years between the two years can % 400 = 0
			flag_400 = ((Date[1].year /100) % 4 + (Date[0].year /100) - (Date[1].year /100)) / 4;
		}
		else
		{
			flag_400 = 0;
		}

		leap_year_cnt = ((Date[1].year % 4 + dyear) / 4 + is_leap_year[1]) - (Date[0].year /100) + (Date[1].year /100) + flag_400;//calculate how many leap years
								//�����������ж�������                                          //��ȥ�м��ж��ٰ���                                  //���Ͽɱ�400�����İ���						

		return dyear * 365 + leap_year_cnt + days[0] - days[1];
	}
	else                                                                                           //the two days is in the same year
	{
		if (days[0] > days[1])
		{
			return days[0] - days[1];
		}
		else
		{
			return days[1] - days[0];
		}
	}
}