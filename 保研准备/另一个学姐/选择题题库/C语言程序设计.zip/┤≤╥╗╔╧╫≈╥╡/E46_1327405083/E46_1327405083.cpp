//combine two files together

#include <stdio.h>
#include <stdlib.h>

void main()
{
	FILE *fp[2],*new_fp;
	char ch,filename[3][10];
	int i;

	for(i = 0;i < 2;i++)                                           //input the names of the two original files
	{
		printf("Please input the file%d's name:",i+1);
		scanf("%s",filename[i]);

		if ((fp[i] = fopen(filename[i],"r")) == NULL)              //judge whether the files are exist
		{
			printf("Sorry!The file cannot be found.\n");
			exit(0);
		}
	}
	
	printf("Please input the new file's name:");                   //input the name of the new file
	scanf("%s",filename[2]);
	if ((new_fp = fopen(filename[2],"w")) == NULL)
	{
		printf("Sorry!The file cannot be found.\n");               //judge whether the new file is exist
		exit(0);
	}

	for(i = 0;i < 2;i++)                                           //attach the original files to the new file
	{
		while(!feof(fp[i]))
		{
			ch = fgetc(fp[i]);
			fputc(ch,new_fp);
			putchar(ch);                                           //display the new file
		}
	}
	
	for(i = 0;i < 2;i++)                                           //close the files
	{
		fclose(fp[i]);
	}
	fclose(new_fp);
}