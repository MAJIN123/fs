#include <stdio.h>
void main()
{
	int i,n,rest;                                    //define the variables

	n = 0;                                           //calculate how many choices do we have
	
	for(i = 10;i >= 0;i--)                           //initialize the variable
	{
		rest = 50 - i * 5;
		n = n + (rest / 2) + 1; 
	}

	printf("we have %d choices",n);                   //output the result
}