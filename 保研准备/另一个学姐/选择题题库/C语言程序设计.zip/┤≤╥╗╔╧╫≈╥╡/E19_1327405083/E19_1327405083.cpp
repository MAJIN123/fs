//use ɸ�� to find out primes between 1 and 100

#include <stdio.h>
void main()
{
	int i,j,cnt = 0,arr[100];                              //define the variables

	for(i = 2;i < 100;i++)
	{
		if(i == 2)                                         //confirm 2 is a prime,output it and add up the counter
		{
			arr[cnt] = i;
			printf("%-5d",arr[cnt]);
			cnt++;
		}
		else
		{
			for(j = 0;j < cnt;j++)
			{
				if(i % arr[j] == 0)                        //judge whether i is a prime
				{
					break;
				}
			}

			if(j == cnt)
			{
				arr[cnt] = i;
				printf("%-5d",arr[cnt]);                   //output the result and add up the counter
				cnt++;

				if(cnt % 10 == 0)                          //control the form of output
				{
					 printf("\n");
				}
			}
		}
	}

	printf("\nare primes\n");                              //claim what is the result
}