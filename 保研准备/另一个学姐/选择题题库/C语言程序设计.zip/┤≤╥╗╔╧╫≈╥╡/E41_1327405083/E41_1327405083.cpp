//create a linked list and delete the nodes which store an even number

#include <stdio.h>
#include <stdlib.h>

struct Node
{
	int Integer;

	struct Node *Next;
};

struct Node* func_CreateList();                               //a function to create a linked list 
void func_DisplayList(struct Node*);                          //a function to display the linked list
struct Node* func_DeleteNode(struct Node*);                   //a function to delete(free) some nodes
struct Node* func_FreeList(struct Node*);                     //a function to free the linked list

void main()
{
	struct Node *head;

	printf("Please input some integers and input -9999 to stop:\n");
	head = func_CreateList();                                 //call function to create a linked list and return the head address of the linked list

	printf("The linked list is:\n");
	func_DisplayList(head);                                   //call function to display the linked list

	head = func_DeleteNode(head);                             //call function to delete(free) some nodes and return the head address of the linked list

	printf("The new linked list is:\n");
	func_DisplayList(head);                                   //call function to display the new linked list

	head = func_FreeList(head);                               //call function free the linked list
}

struct Node* func_CreateList()
{
	struct Node *p,*q;
	struct Node *head;
	int tmp;                                                  //tmp is for storing the score temporarily

	head = (struct Node*)malloc(sizeof(struct Node));         //create the head of the linked list
	q = head;

	while(1)
	{
		scanf("%d",&tmp);

		if (tmp == -9999)                                     //if input -9999,the linked list is over
		{
			break;
		}

		p = (struct Node*)malloc(sizeof(struct Node));        //else//create a new node
		p->Integer = tmp;                                           //store the score in the new node
		q->Next = p;                                                //let the former node point to the new node
		q = p;                                                      //let the pointer q move forward
	}
	q->Next = NULL;                                           //declare the linked list is over

	return head;                                              //return the head of the linked list
}

void func_DisplayList(struct Node *Head)
{
	struct Node *p;
	int cnt = 0;                                              //a counter to accumulate the number of integers

	p = Head->Next;

	while(p != NULL)
	{
		printf("%-5d",p->Integer);                            //print a integer
		p = p->Next;                                          //let the pointer p point to next node

		cnt++;
		if (cnt % 10 == 0)                                    //ten integers a line
		{
			printf("\n");
		}
	}
	if (cnt % 10 != 0)                                        //control the form of display
	{
		printf("\n");
	}
}

struct Node* func_DeleteNode(struct Node *Head)
{
	struct Node *p,*q;

	q = Head;
	p = q->Next;

	while(p != NULL)
	{
		if (p->Integer % 2 == 0)                              //if the node store an even number,delete(free) the node
		{
			q->Next = p->Next;                                      //let the former node point to the node next to the one which will be deleted(freed)
			free(p);
			p = q->Next;
		}
		else
		{
			p = p->Next;                                      //else//let the pointers move forward
			q = q->Next;
		}
	}

	return Head;                                              //return the head of the linked list
}

struct Node* func_FreeList(struct Node *Head)
{
	struct Node *p,*q;

	q = Head;

	while(q != NULL)
	{
		p = q->Next;                                          //let the pointer p point to the next node
		free(q);                                              //free the node which point q pionts to
		q = p;                                                //let the pointer q point to the pointer p
	}

	return NULL;
}