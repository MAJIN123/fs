#include <stdio.h>
void main()
{
	int a,n,an,Sn,i,judge;                                              //define the variables

	judge = 0;                                                          //initialize the varibles     

	do                                                                  
	{
		printf("please input a number a and a number n\n");             //input the datas
		scanf("%d%d",&a,&n);
		
		if(0 <= a && a < 10)                                            //whether the number is between 0 and 9
		{
			an = a;                                                     //initialize the variable
			Sn = an;
		
			for(i = 0;i<n - 1;i++)                                      //add up every number 
			{
				an = an * 10 + a;
				Sn = Sn + an;
			}

			judge = 0;                                                  //change the command variable
		}
		else
		{
			printf("\n\nplease input a number between 0 and 9\n");            //input again
			judge = 1;
		}

	}while(judge == 1);

	printf("Sn = %d",Sn);                                               //output the result
}