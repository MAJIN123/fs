#include <stdio.h>
void main()
{
	int i;
    double a,b,Sn,q,r,s,t;                                  //define the variables
	
	q = 1.0;                                                //initialize the varibles
	r = 1.0;
	a = 2.0;
	b = 1.0;
	Sn = 0.0;

	for(i = 0;i < 20;i++)                                   //add up the numbers
	{
		Sn = Sn + (a / b);
		s = a;                                              //exchange the numbers
		t = b;
		a += q;
		b += r;
		q = s;
		r = t;
	}

	printf("the sum of the numbers is %.2lf\n",Sn);         //output the result
}