//���8���������

#include<stdio.h>
void main()
{
	int arr[8][15] = {},row,column;                                                //define the variables for circulate and initialize the array arr

	for(row = 0;row < 8;row++)                                                     //initialize the two sides of the triangle
	{
		arr[row][7-row] = 1;
		arr[row][7+row] = 1;
	}

	for(row = 2;row < 8;row++)                                                     //calculate every number in the triangle 
	{
		for(column = 8 - row + 1;column < 8 + row - 1;column++)
		{
			arr[row][column] = arr[row-1][column-1] + arr[row-1][column+1];
		}
	}

	for(row = 0;row < 8;row++)                                                     //print the triangle
	{
		for(column = 0;column < 15;column++)
		{
			if(arr[row][column] == 0)
			{
				printf("   ");                                                     //control the form of print
			}
			else
			{
				printf("%-3d",arr[row][column]);
			}
		}
		printf("\n");
	}
}	