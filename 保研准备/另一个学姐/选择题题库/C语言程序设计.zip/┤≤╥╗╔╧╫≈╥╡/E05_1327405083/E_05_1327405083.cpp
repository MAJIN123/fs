#include <stdio.h>
void main()
{
	char a;

	printf("please input a letter\n");
	scanf("%c",&a);

	printf("the letter %c's ASCII is %d\n",a,a);
}