#include <stdio.h>
void main()
{
	int num,a,b,c,d,e;                                                  //define the variable

	printf("please input the number\n");                                //input the variable
	scanf("%d",&num);

	if(num < 0 || num >99999)                                           //judge weather the numble meets the requirement 
	{
		printf("please input a postive integer below 100000\n");
	}
	else
	{
		a = num / 10000;                                                 //divide the number into single number 
		b = num / 1000 - a * 10;
		c = num / 100 - (b * 10 + a * 100);
		d = num / 10 - (c * 10 + b * 100 + a * 1000);  
		e = num % 10;

		if(a == 0)                                                       //output the single number and reunion the number     
		{
			if(b == 0)
			{
				if(c == 0)
				{
					if(d == 0)
					{
						printf("the number is %d\n",e);
						num = e;
					}
					else
					{
						printf("the numbers is %d and %d\n",d,e);
						num = e * 10 + d;
					}
				}
				else
				{
					printf("the numbers is %d , %d and %d\n",c,d,e);
					num = e * 100 + d * 10 + c;
				}				
			}
			else
			{
				printf("the numbers is %d , %d , %d and %d\n",b,c,d,e);
				num = e * 1000 + d * 100 + c * 10 + b;
			}
		}
		else
		{
			printf("the numbers is %d , %d , %d , %d and %d\n",a,b,c,d,e);
			num = e * 10000 + d * 1000 + c * 100 + b * 10 + a;
		}
		printf("the inverted order of the number is %d\n",num);	                          //output the new number
	}
}