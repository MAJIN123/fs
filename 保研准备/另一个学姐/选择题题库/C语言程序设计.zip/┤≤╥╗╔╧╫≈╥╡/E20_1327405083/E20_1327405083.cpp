//use ѡ�� orderify 10 random numbers

#include <stdio.h>
#include <time.h>
#include <stdlib.h>
void main()
{
	unsigned int i,j,temp,arr[10],min;                               //define the variables

	srand(time(NULL));                                               //produce ten random numbers
	for(i = 0;i < 10;i++)
	{
		arr[i] = rand()%10000;
	}

	for(i = 0;i < 9;i++)                                             //orderify the ten numbers by ascending order
	{
		min = i;
		for(j = i + 1;j < 10;j++)
		{
			if(arr[min] > arr[j])                                    //exchange min,arr[j] and the two numbers
			{
				temp = arr[j];
				arr[j] = arr[min];
				arr[min] = temp;
				min = j;
			}
		}
	}

	printf("orderify the ten numbers by ascending order:\n");        //output the result by ascending order
	for(i = 0;i < 10;i++)
	{
		printf("%-5d",arr[i]);
	}
	printf("\n");
}