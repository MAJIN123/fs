#include <stdio.h>
void main()
{
	char a,A;

	printf("please input a letter\n");
	scanf("%c",&a);

	A = a - 32;

	printf("the initial of letter %c is %c\n",a,A);
}