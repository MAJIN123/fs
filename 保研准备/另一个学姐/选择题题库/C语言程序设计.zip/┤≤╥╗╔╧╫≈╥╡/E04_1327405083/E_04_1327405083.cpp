#include <stdio.h>
void main()
{
	int num,a,b,c,sum;

	printf("please input a three-digit number\n");
	scanf("%d",&num);

	if(num >99 && num < 1000)
	{
		a = num / 100;
		b = (num - a * 100) / 10;
		c = num % 10;
		sum = a + b + c;
		printf("the sum of the three number is %d",sum);
	}	
	else
		printf("wrong number");
}