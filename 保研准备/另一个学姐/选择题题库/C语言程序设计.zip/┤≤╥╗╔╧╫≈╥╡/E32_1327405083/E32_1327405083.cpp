//Turn decimal number to binary number

#include <stdio.h>

int func_Binary(int,int arr[]);                               //define the function for turning decimal to binary

void main()
{
	int n,arr[1000],cnt,i;                                    //define the variables for a decimal number,array and for circulates

	printf("Please input a decimal number:\n");               //input a decimal number
	scanf("%d",&n);

	cnt = func_Binary(n,arr);                                 //call function to turn a decimal number to binary number

	printf("The decimal to binary is:\n");                    //print the number in binary system
	for(i = 0;i < cnt;i++)
	{
		printf("%-2d",arr[i]);
	}
}

int func_Binary(int N,int Arr[])
{
	int mod,cnt = 0;                                          //define the variables for store 1,0 and for count the digit

	if(N < 2)                                                 //give the termination condition for recursion
	{
		Arr[cnt++] = N;
		return cnt;
	}
	else                                                      //use short division to calculate every digit
	{
		mod = N % 2;                                         
		N /= 2;
		cnt = func_Binary(N,Arr);                             //recursion
		Arr[cnt++] = mod;
	}
}