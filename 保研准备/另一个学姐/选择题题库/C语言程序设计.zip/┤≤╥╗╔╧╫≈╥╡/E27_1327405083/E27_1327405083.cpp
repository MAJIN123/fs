#include <stdio.h>
void main()
{
	int word_cnt = 0,letter_cnt = 0,i = 0;                                              //define the variables for counters and strings
	char str[1001],words[200][21] = {};
	
	printf("Please input a sentence:\n");                                                //input the sentence
	gets(str);

	while(str[i] != '\0')                                                                        //judge whether the string is over
	{
		if(str[i] == ' ' || str[i] == ',' || str[i] == ';' || str[i] == '.')                //judge whether a word is over
		{
			i++;                                                                                   //number of words add one,i++ and let the letter[i+1] store into the next line's first column 
			word_cnt++;
			letter_cnt = 0;
		}
		else
		{
			words[word_cnt][letter_cnt++] = str[i++];                                //store the letter str[i] into words[][]
		}
	}

	for(i = 0;i <= word_cnt;i++)                                                            //print the words one a line
	{
		printf("%s\n",words[i]);
	}
}