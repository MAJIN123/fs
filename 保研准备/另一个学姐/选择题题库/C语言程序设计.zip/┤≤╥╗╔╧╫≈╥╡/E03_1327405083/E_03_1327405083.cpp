#include <stdio.h>
#define pi 3.14
void main()
{
	double r,c,s,v,S;

	printf("please input the radius of the circle\n");
	scanf("%lf",&r);

	c = 2 * pi * r;
	s = pi * r * r;
	v = r * r * r * pi * 4 / 3;
	S = 4 * r * r * pi;

	printf("the perimeter of the circle is %.2lf\nthe area of the circle is %.2lf\nthe volume of the circle is %.2lf\nthe superficial area of the circle is %.2lf\n",c,s,v,S);
}