//use point to sort numbers

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void func_Produce(int*,int);               //declare   //the function is to produce numbers
void sort(int*,int);                                   //the function is to sort the numbers
void func_Print(int*,int);                             //the function is to print the numbers

void main()
{
	int n;                                 //n is the number of the numbers

	printf("Please input how many numbers do you want to sort:\n");
	scanf("%d",&n);                        //input how many numbers do you want to sort
	
	int *p = (int*)malloc(sizeof(int)*n);  //apply the space to store the numbers

	func_Produce(p,n);                     //call function to produce n numbers

	printf("The %d numbers are:\n",n);     //call function to print the numbers before sort
	func_Print(p,n);

	sort(p,n);                             //call function to sort the numbers

	printf("The sorted numbers numbers are:\n");//call function to print the sorted numbers
	func_Print(p,n);

	free(p);                               //release the space
}

void func_Produce(int Arr[],int N)
{
	int i;

	srand(time(NULL));                     //produce n random numbers by time
	for(i = 0;i < N;i++)
	{
		Arr[i] = rand()%1000;              //control the numbers are lower than 1000
	}
}

void func_Print(int Arr[],int N)
{
	int i;

	for(i = 0;i < N;i++)                   //print the array
	{
		printf("%-5d",Arr[i]);

		if ((i+1) % 10 == 0)               //control 10 numbers a line
		{
			printf("\n");
		}
	}
	printf("\n");                          //separate the result
}

void sort(int Arr[],int N)
{
	int i,j,max_inx,tmp;

	for(i = 0;i < N-1;i++)                 //use ѡ�� to sort the numbers
	{
		max_inx = i;
		for(j = i+1;j < N;j++)
		{
			if (Arr[max_inx] < Arr[j])
			{
				max_inx = j;
			}
		}
		if (max_inx != i)
		{
			tmp = Arr[i];
			Arr[i] = Arr[max_inx];
			Arr[max_inx] = tmp;
		}
	}
}