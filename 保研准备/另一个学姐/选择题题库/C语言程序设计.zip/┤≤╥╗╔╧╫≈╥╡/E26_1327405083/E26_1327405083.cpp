//judge whether the s2 is s1's subset

#include <stdio.h>
void main()
{
	char str1[101],str2[101];                               //define the variables for string1 and string2
	int cnt1 = 0,cnt2 = 0,i,j,judge;

	printf("Please input string s1:\n");                    //input two strings
	scanf("%s",str1);
	printf("Please input string s2:\n");
	scanf("%s",str2);

	while(str1[cnt1] != '\0')                               //count how the two strings are
	{
		cnt1++;
	}
	while(str2[cnt2] != '\0')
	{
		cnt2++;
	}

	if(cnt1 < cnt2)                                         //judge by the length of the two stings
	{
		printf("s2 is not s1's subset\n");                               //print the whether s2 is s1's subset
		return;
	}

	for(i = 0;i < cnt1 - cnt2 + 1;i++)                                 //judge by comparing one letter and one letter
	{
		if(str1[i] == str2[0])                                          //find out the same letter in s1 which is the initial of s2
		{
			for(j = 1;j < cnt2;j++)
			{
				if(str1[i+j] != str2[j])                                //compare the letters afterwords
				{
					break;
				}
			}
			if(j == cnt2)                                               //print the whether s2 is s1's subset
			{
				printf("s2 is s1's subset\n");
				judge = 1;
				break;
			}
		}
	}

	if(judge != 1)
	{
		printf("s2 is not s1's subset\n");                              //print the whether s2 is s1's subset
	}
}