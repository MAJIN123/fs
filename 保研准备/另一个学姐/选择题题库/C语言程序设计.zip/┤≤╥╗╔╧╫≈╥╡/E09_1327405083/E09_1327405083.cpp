#include <stdio.h>
void main()
{
	int a;                                                      //define the variable

    printf("please input the number of the month\n");           //input the month number
	scanf("%d",&a);

	switch(a)                                                   //judge how many days the month have
	{
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			printf("the month has 31 days");
			break;
		case 2:
			printf("the month has 28 days");
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			printf("the month has 31 days");
			break;		

		default:
			printf("you have put a wrong number\n");
			break;
	}
}