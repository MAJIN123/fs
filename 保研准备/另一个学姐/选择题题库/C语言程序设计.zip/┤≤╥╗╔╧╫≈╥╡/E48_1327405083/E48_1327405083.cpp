//read a binary text,sort,write a new ASCII text

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define N 20

int Read_Binary_Text(char*,int*,int);										 //function to read the binary text
void Sort(int*,int);														 //function to sort the numbers
void Display(int*,int);														 //function to display the array
int Write_ASCII_Text(char*,int*,int);										 //function to write the numbers into an ASCII text

void main()
{
	int num[N];
	int res;                                                                 //use the judge whether the filename can be found
	char fname_binary[21],fname_ASCII[21];

	printf("Please input the name of the binary text you want to open:\n");  //read the binary text
	scanf("%s",fname_binary);
	res = Read_Binary_Text(fname_binary,num,N);
	if (res == 0)                                                            //if the filename cannot be found
	{
		printf("Sorry.The text cannot be found.\n");
		return;
	}

	printf("\nDisplay the original numbers:\n");                             //call function to display the original array
	Display(num,N);

	Sort(num,N);                                                             //call function to sort the array

	printf("\nDisplay the sorted numbers:\n");                               //call function to display the sorted array
	Display(num,N);

	printf("\nPlease input the name of the ASCII text you want to write:\n");//write the numbers into an ASCII text
	scanf("%s",fname_ASCII);
	strcat(fname_ASCII,".txt");
	res = Write_ASCII_Text(fname_ASCII,num,N);
	if (res == 0)                                                            //if the file cannot be found
	{
		printf("Sorry.The text cannot be found.\n");
		return;
	}
}

int Read_Binary_Text(char FName[],int Arr[],int Cnt)
{
	FILE *fp;

	fp = fopen(FName,"rb");                                                   //open the binary text
	if (fp == NULL)                                                           //if the text cannot be found
	{
		return 0;
	}

	fread(Arr,sizeof(int),Cnt,fp);                                            //read the text and write the numbers into an array

	fclose(fp);                                                               //close the text

	return 1;                                                                 //means that the text is exist
}

void Sort(int Arr[],int Cnt)
{
	int i,j;
	int min_inx;
	int tmp;

	for(i = 0;i < Cnt-1;i++)                                                  //use ѡ�� sort the array
	{
		min_inx = i;
		for(j = i;j < Cnt;j++)
		{
			if (Arr[min_inx] > Arr[j])
			{
				min_inx = j;
			}
		}
		if (min_inx != i)
		{
			tmp = Arr[min_inx];
			Arr[min_inx] = Arr[i];
			Arr[i] = tmp;
		}
	}
}

void Display(int Arr[],int Cnt)
{
	int i;

	for(i = 0;i < Cnt;i++)                                                    //display the numbers
	{
		printf("%-10d",Arr[i]);

		if((i+1) % 5 == 0)                                                    //control five numbers a line
		{
			printf("\n");
		}
	}
	if (i % 5 != 0)                                                           //control the form
	{
		printf("\n");
	}
}

int Write_ASCII_Text(char FName[],int Arr[],int Cnt)
{
	FILE *fp;
	int i;

	fp = fopen(FName,"w");                                                    //open the ASCII text
	if (fp == NULL)                                                           //if the text cannot be found
	{
		return 0;
	}

	for(i = 0;i < Cnt;i++)                                                    //write one number a line into the text
	{
		if (i == 0)                                                           //don't make a "\n" in the final
		{
			fprintf(fp,"%d",Arr[i]);
			continue;
		}

		fprintf(fp,"\n%d",Arr[i]);
	}
}