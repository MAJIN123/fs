#include <stdio.h>
void main()
{
	int cock,hen,chicken,rest,i,j,n;                                       //define the variables

	n = 1;                                                                 //initialize the variable

	for(i = 100 / 5;i >= 0;i--)                                             //calculate how many cock,hen and chicken//cock
	{
		for(j = 0;j <= 100 / 3;j++)                                        //hen
		{
			rest = 100 - (i * 5 + j * 3);                                  //chicken
			if(i + j + rest * 3 == 100)    
			{
				cock = i;
				hen = j;
				chicken = rest * 3;

				printf("choice %d:\n",n);                                  //output the result of the procedure  
				printf("cock:%10d\nhen:%11d\nchicken:%7d\n\n",cock,hen,chicken);

				n++;                                                       //count the order of the choice
			}
		}
	}
}