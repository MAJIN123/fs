#include <stdio.h>
void main()
{
	int month,date,n;                              //define the variables

	printf("please input the month\n");            //input the variables
	scanf("%d",&month);
	printf("please input the date\n");
	scanf("%d",&date);

	switch(month)                                  //judge how many days away form 2013.1.1
	{
	case 1:
		n = 0;
		break;
	case 2:
		n = 31;
		break;
	case 3:
		n = 59;
		break;
	case 4:
		n = 90;
		break;
	case 5:
		n = 120;
		break;
	case 6:
		n = 151;
		break;
	case 7:
		n = 181;
		break;
	case 8:
		n = 212;
		break;
	case 9:
		n = 243;
		break;
	case 10:
		n = 273;
		break;
	case 11:
		n = 304;
		break;
	case 12:
		n = 334;
		break;
	default:
		printf("you have input a wrong number\n");
	}

	n = (n + date - 1) % 7;

	switch(n)                                                       //judge what day is it the day and output the result
	{
	    case 1:
			printf("Today is Wednesday.\n");
			break;
		case 2:
			printf("Today is Thusday.\n");
			break;
		case 3:
			printf("Today is Friday.\n");
			break;
		case 4:
			printf("Today is Saturday.\n");
			break;
	    case 5:
			printf("Today is Sunday.\n");
			break;
	    case 6:
			printf("Today is Monday.\n");
			break;
		default:
			printf("Today is Tuesday.\n");
	}

}