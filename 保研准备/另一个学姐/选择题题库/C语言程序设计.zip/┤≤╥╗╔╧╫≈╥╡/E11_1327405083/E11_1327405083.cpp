#include <stdio.h>
#include <math.h>
void main()
{
	double x1,x2,y1,y2,r,d;                                                     //define the variable

	printf("please input the coordinat of the centre of the circle\n");         //input the variables
	scanf("%lf%lf",&x1,&y1);
	printf("please input the radius of the circle\n");
	scanf("%lf",&r);
	printf("please input the coordinate of the point\n");
	scanf("%lf%lf",&x2,&y2);

	d = sqrt(pow(x1 - x2,2) + pow(y1 - y2,2));                                  //judge the location of the point
	if(d < r)
	{
		printf("the point is in the circle\n");
	}
	else
		if(d == r)
		{
			printf("the point is on the circle\n");
		}
		else
		{
			printf("the point is out of the cicle\n");
		}
}