#include <stdio.h>
void main()
{
	int a ,b,c,s,sum;
	double ave = 0.0;

	printf("please input three numbers\n");
	scanf("%d%d%d",&a,&b,&c);

	sum = a + b + c;
	ave = sum / 3.0;

	if(a < b)
	{
		s = a;
		a = b;
		b = s;
	}
	if(a < c)
	{
		s = a;
		a = c;
		c = s;
	}
	if(b < c)
	{
		s = b;
		b = c;
		c = s;
	}

	printf("sum = %d,average = %.2lf,maximum = %d,minimum = %d\n",sum,ave,a,c);
}