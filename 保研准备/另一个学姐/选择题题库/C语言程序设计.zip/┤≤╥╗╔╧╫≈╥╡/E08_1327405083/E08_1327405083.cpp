#include <stdio.h>
#include <math.h>
void main()
{
	double x1,x2,x3,y1,y2,y3,a,b,c,C,S,s;                                               //define the variables

	printf("please input the coordinate of point A\n");                                 //input the coordinate of the three points
	scanf("%lf%lf",&x1,&y1);
	printf("please input the coordinate of point B\n");
	scanf("%lf%lf",&x2,&y2);	
	printf("please input the coordinate of point C\n");
	scanf("%lf%lf",&x3,&y3);

	a = sqrt(pow(x1 - x2,2) + pow(y1 - y2,2));                                          //calculate the three sides of the triangle 
	b = sqrt(pow(x2 - x3,2) + pow(y2 - y3,2));
	c = sqrt(pow(x3 - x1,2) + pow(y3 - y1,2));
	
	if(a + b<= c||b + c<= a||c + a <= b)                                                //judge the three pionts can or cannot consist a triangle 
	{
		printf("the three point cannot consist a triangle\n");
	}
	else
	{
		C = a + b + c;                                                                  //calculate the perimeter and area of the triangle 
		s = C / 2.0;
		S = sqrt(s * (s - a) * (s - b) * (s - c));
		printf("the perimeter of the triangle is %.2lf\nthe area of the triangle is %.2lf\n",C,S);         //output the result of the procedure
	}
}