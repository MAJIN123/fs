//transform a string into a maximum number and a minimum number

#include <stdio.h>
#include <string.h>

void Max_Min(char*,int*,int*);                                     //declare the function to transform the string

void main()
{
	char str[6];                                                   //str for storing the string
	int max = 0,min = 0;                                           //max and min for storing the results

	printf("Please input numbers less than 6 digit:\n");           //input a string
	scanf("%s",str);

	Max_Min(str,&max,&min);                                        //call the function to transform the string

	printf("The max number is: %d\nThe min number is: %d\n",max,min);  //print the maximun and minimum numbers
}

void Max_Min(char Str[],int *Max,int *Min)
{
	int len = strlen(Str);                                         //len is the length of the string
	int i,j,max_inx;
	char tmp;

	for(i = 0;i < len-1;i++)                                       //use ѡ�� sort the string
	{
		max_inx = i;
		for(j = i+1;j < len;j++)
		{
			if (Str[max_inx] < Str[j])
			{
				max_inx = j;
			}
		}
		if (max_inx != i)
		{
			tmp = Str[i];
			Str[i] = Str[max_inx];
			Str[max_inx] = tmp;
		}
	}
	
	for(i = 0;i < len;i++)                                         //calculate the maximum number
	{
		*Max = *Max * 10 + Str[i] - '0';
	}

	while(Str[--i] == 0)                                           //exclude the condition that the string has '0'
	{
		if (i < 0)                                                 //the condition that all character are '0'
		{
			break;
		}
	}

	if(i > 0)                                                      //the condition that not all the character is '0'
	{                                                              //and calculate the minimum number
		for(j = i;j >= 0;j--)
		{
			*Min = *Min * 10 + Str[j] - '0';
		}
	}
}