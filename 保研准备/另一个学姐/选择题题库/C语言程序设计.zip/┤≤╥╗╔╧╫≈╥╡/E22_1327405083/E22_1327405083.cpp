//exclude the repetitive numbers in the array and orderify the array

#include <stdio.h>
void main()
{
	int i,j,x[12] = {35,46,57,13,24,35,99,68,13,79,88,46},cnt = 12,temp;         //define the variables for circulate and initialize the array x

	for(i = 0;i < 11;i++)
	{
		for(j = i + 1;j < 12;j++)                                                //change the repetitive number into zero
		{
			if(x[i] == x[j])
			{
				cnt--;
				x[i] = 0;
				break;
			}
		}
	}

	for(i = 0;i < 12;i++)                                                        //orderify the new array x
	{
		for(j = 0;j < 11 - i;j++)
		{
			if(x[j] > x[j+1])
			{
				temp = x[j];                                                    //exchange two number which in wrong order
				x[j] = x[j+1];
				x[j+1] = temp;
			}
		}
	}

	printf("This is the new array:\n");                                         //print the new array without repetitive number
	for(i = 12 - cnt;i < 12;i++)
	{
		printf("%-3d",x[i]);
	}
}