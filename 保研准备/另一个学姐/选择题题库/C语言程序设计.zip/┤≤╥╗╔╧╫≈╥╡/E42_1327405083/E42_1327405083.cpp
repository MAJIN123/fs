//make a telephone directory and do some operation

#include <stdio.h>
#include <string.h>

#define N 50

struct Directory
{
	char name[11];
	char telephone[12];
	char mobile_phone[12];
	char postcode[7];
	char address[16];
};

void func_Record(struct Directory*,int);              //a function to record information
void func_Display(struct Directory*,int);             //a function to display information
int func_Delete(struct Directory*,char*,int);         //a function to delete information
void func_Revise(struct Directory*,char*,int);        //a function to revise information
void func_Inquire(struct Directory*,char*,int);       //a function to inquire information

void main()
{
	struct Directory directory[N];
	int n,choice;                                     //n is the number of people's information that you would like to record//choice is for storing the command1,2,3or0
	char name[11];                                    //name is for storing the people's name which you want to do operation on

	printf("How many people do you want to record:\n");
	scanf("%d",&n);

	func_Record(directory,n);                         //call function to record information

	printf("\n\nPlease check it whether they are all right:\n");
	func_Display(directory,n);                        //call function to display the directory

	while(1)
	{
		printf("input 1 for delete,input 2 for revise,input 3 for inquire,input 0 for quit.\n");//which function do you want to call:1,2,3or0
		printf("Which function would you like to choose:\n");
		scanf("%d",&choice);

		if (choice == 0)                              //choice = 0,stop the program
		{
			printf("\n\nThank you for using this program!\n");
			return;
		}

		if (choice == 1)                              //choice = 1,delete a person's information
		{
			printf("Whose informationg would you like to delete:\n");
			scanf("%s",name);
			n = func_Delete(directory,name,n);        //call function to delete the person's information
		}

		if (choice == 2)                              //choice = 2,revise a person's information
		{
			printf("Whose information would you like to revise:\n");
			scanf("%s",&name);
			func_Revise(directory,name,n);            //call function to revise the person's information
		}

		if (choice == 3)                              //choice = 3,inquire a person's information
		{
			printf("Whose information would you like to inquire:\n");
			scanf("%s",name);
			func_Inquire(directory,name,n);           //call function to inquire the person's information
		}

		printf("\n\nPlease check it whether they are all right:\n");
		func_Display(directory,n);                    //call function to display the directory after operating
	}

}

void func_Record(struct Directory Directory[],int No) //function to record
{
	int i;

	for(i = 0;i < No;i++)
	{
		printf("Please input the No.%d's name,telephone,mobile phone,postcode and address:\n",i+1);
		scanf("%s%s%s%s%s",Directory[i].name,Directory[i].telephone,Directory[i].mobile_phone,Directory[i].postcode,Directory[i].address);
	}
}

void func_Display(struct Directory Directory[],int No)//function to display
{
	int i;

	printf("      *name         *telephone      *mobile phone   *postcode *address\n");
	for(i = 0;i < No;i++)
	{
		printf("No.%02d *%-13s*%-15s*%-15s*%-9s*%-15s\n",i+1,Directory[i].name,Directory[i].telephone,Directory[i].mobile_phone,Directory[i].postcode,Directory[i].address);
	}
	printf("\n************************************************************************\n\n");
}

int func_Delete(struct Directory Directory[],char Name[],int No)//function to delete
{
	int i,j;

	for(i = 0;i < No;i++)
	{
		if (strcmp(Name,Directory[i].name) == 0)                //find the person's name in the directory
		{
			for(j = i;j < No - 1;j++)
			{
				Directory[j] = Directory[j+1];                  //let the information afterward move forward
			}
			return No-1;                                        //the sum of the people in the directory reduce 1
		}
	}
	if (i == No)                                                //the person's name can't be found in the directory
	{
		printf("Sorry.There isn't %s in the directory.\n",Name);
	}

	return No;
}

void func_Revise(struct Directory Directory[],char Name[],int No)//function to revise
{
	int i;

	for(i = 0;i < No;i++)
	{
		if (strcmp(Name,Directory[i].name) == 0)                 //find the person's name in the directory
		{
			printf("Please input &s's information again:\n",Name);//record new information
			scanf("%s%s%s%s%s",Directory[i].name,Directory[i].telephone,Directory[i].mobile_phone,Directory[i].postcode,Directory[i].address);
			break;
		}
	}
	if (i == No)                                                 //the person's name can't be found in the directory
	{
		printf("Sorry.There isn't %s in the directory.\n",Name); 
	}
}

void func_Inquire(struct Directory Directory[],char Name[],int No)//function to inquire
{
	int i;
	struct Directory tmp[1];                                      //tmp use to store the person's information and give the array's address to func_Display

	for(i = 0;i < No;i++)
	{
		if (strcmp(Name,Directory[i].name) == 0)                  //find the person's name in the directory
		{
			tmp[0] = Directory[i];
			func_Display(tmp,1);                                  //call func_Display to display the person's information
			break;
		}
	}
	if (i == No)                                                  //the person's name can't be found in the directory
	{
		printf("Sorry.There isn't %s in the directory.\n",Name);
	}
}