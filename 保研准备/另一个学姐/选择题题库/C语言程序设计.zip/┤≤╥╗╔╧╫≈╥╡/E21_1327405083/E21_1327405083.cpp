//insert a number into the array and orderify the array

#include <stdio.h>
void main()
{
	int x[10] = {13,24,35,46,57,68,79,88,93},i,j,temp,num;             //define the variables for circulate and initialize the array x

	printf("please input a number:\n");                                //give a number to x[9]
	scanf("%d",&num);

	if(num >= x[8])                                                    //judge whether num is the maximum number in the array
	{
		x[9] = num;
	}
	else
	{
		if(num < x[0])                                                 //judge whether num is the minimum number in the array
		{
			for(i = 9;i > 0;i--)
			{
				x[i] = x[i-1];
			}
			x[0] = num;
		}
		else
		{
			for(i = 0;i < 8;i++)                                       //settle the other conditions  
			{
				if(x[i] <= num && num < x[i+1])
				{
					for(j = 9;j > i + 1;j--)
					{
						x[j] = x[j-1];
					}
					x[i+1] = num;
					break;
				}
			}
		}
	}

	printf("insert the new number into the array:\n");                //output the new array by ascending order
	for(i = 0;i < 10;i++)
	{
		printf("%-3d",x[i]);
	}
	printf("\n");
}