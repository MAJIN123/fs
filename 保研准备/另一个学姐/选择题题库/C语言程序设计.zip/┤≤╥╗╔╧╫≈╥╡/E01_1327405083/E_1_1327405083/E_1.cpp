#include <stdio.h>
void main()
{
	int a,b,quo,mod;

	printf("please input number a and b\n");
	scanf("%d%d",&a,&b);

	quo = a / b;
	mod = a % b;

	printf("a / b = %d,a mod b = %d\n",quo,mod);
}