//use function to find out the primes between 1 and 1000

#include <stdio.h>

int func_Prime(int);                                //define the function which is used to find out primes

void main()
{
	int arr[1000],cnt = 0,i;                       //define the array to store the primes and the variables for counter and circulate

	for(i = 1;i <= 1000;i++)
	{
		if(func_Prime(i))                            //call function the judge whether i is a prime
		{
			arr[cnt++] = i;                          //store the prime
		}
	}

	printf("Primes are:\n");                        //input the primes
	for(i = 0;i < cnt;i++)
	{
		printf("%-5d",arr[i]);
		if((i+1) % 8 == 0)                          //control every eight number a line
		{
			printf("\n");
		}
	}
}

int func_Prime(int I)
{
	int i,cnt = 0;
	for(i = 1;i <= I;i++)                           //calculate how many prime does i have
	{
		if(I % i == 0)
		{
			cnt++;
		}
		if(cnt > 2)                                   //a prime only has two divisors
		{
			return 0;
		}
	}

	if(cnt == 2)                                     //judge whether i is a prime by how many divisors does i have
	{
		return 1;
	}
	else
	{
		return 0;
	}
}