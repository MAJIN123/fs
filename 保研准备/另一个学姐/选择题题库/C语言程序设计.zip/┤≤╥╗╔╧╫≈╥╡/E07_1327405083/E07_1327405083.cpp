#include <stdio.h>
#include <math.h>
void main()
{
	double a,b,c,x1,x2,disc;                                                 //define

	printf("please input the coefficient of the equation\n");                //input the coefficient
	scanf("%lf%lf%lf",&a,&b,&c);

	disc = b * b - 4 * a * c;                                                //judje the number of roots and solve the equation
	if(disc < 0)
	{
		printf("the equation has no real roots");
	}
	else
	{
		x1 = ( - b - sqrt(disc))/(2.0 * a);
		x2 = ( - b + sqrt(disc))/(2.0 * a);
    	printf("Answer:\n\nx1 = %.2lf\nx2 = %.2lf\n",x1,x2);                 //output the result of the equation
	}	
}