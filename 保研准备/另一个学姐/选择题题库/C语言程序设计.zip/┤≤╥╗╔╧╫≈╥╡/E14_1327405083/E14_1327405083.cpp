#include <stdio.h>
void main()
{
	int i,j;                                   //define the variables
	char c;
    
	for(i = 0;i<=126 - 32;i++)                 //output the character
	{
		if((i + 1)%5 == 0)
		{
			printf("\n");                      //five character a line
		}
		c = i + 32;
		printf("%10c",c);                      //output
	}
	
}