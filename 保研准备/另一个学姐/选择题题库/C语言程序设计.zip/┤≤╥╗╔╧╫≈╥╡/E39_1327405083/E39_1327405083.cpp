//delete n characters from the Kth(or st or nd or rd) character

#include <stdio.h>
#include <string.h>

void Delchar(char*,int,int);                       //declare the function to delete characters by order

void main()
{
	char str[1001];
	int k,n;                                       //k is the ordinal of the beginning character you want to delete and n is the number of the characters you want to delete

	printf("Please input a string:\n");            //input a string to be deleted character
	scanf("%s",str);

	printf("Which character do you want to begin to delete:\n");
	scanf("%d",&k);

	printf("How many characters do you want to delete:\n");
	scanf("%d",&n);

	Delchar(str,k,n);                              //call function to delete characters by order

	printf("The new string is:\n%s\n",str);
}

void Delchar(char Str[],int K,int N)
{
	int len = strlen(Str),cnt = len,i = 0;

	if (K+N > len)                                //the condition that:K+N is larger than the length of the string
	{
		Str[K-1] = '\0';
	}
	else
	{
		while((K+N+i <= len) && (i < N))          //remove the character that you want to delete
		{
			Str[K+i-1] = Str[K+N+i-1];
			i++;
			cnt--;                                //cnt stands for the length of the new string
		}
		
		Str[cnt] = '\0';                          //the new string is over
	}

}