#include <stdio.h>

void main()
{
	int a[20]={9,20,34,-100,90,123,-203,-1000,293,1,-2,
		1428,89,432,20000,-10012,70,-23,1209,9012};
	int i,j,left,right,mid,num,min_inx,temp;

	for(i=0;i<19;i++)
	{
		min_inx = i;

		for(j=i+1;j<20;j++)
		{
			if (a[min_inx]>a[j])
			{
				min_inx = j;
			}
		}

		if(min_inx != i)
		{
			temp = a[i];
			a[i] = a[min_inx];
			a[min_inx] = temp;
		}
	}

	printf("������Ҫ���ҵ���\n");
	scanf("%d",&num);

	left = 0;
	right = 19;
	while(right-left > 1)
	{
		mid = (right+left)/2;

		if (a[left] == num || a[right] == num || a[mid] == num)
		{
			printf("%d�������д���\n",num);
			return;
		}

		if (a[mid] >= num)
		{
			right = mid;
		}
		else
		{
			left = mid;
		}
	}

	if(a[left] == num || a[right] == num)
	{
		printf("%d�������д���\n",num);
	}
	else
	{
			printf("%d�������в�����\n",num);
	}
}