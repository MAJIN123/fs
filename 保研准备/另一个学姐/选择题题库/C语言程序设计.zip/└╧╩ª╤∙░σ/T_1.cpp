#include <stdio.h>

void main()
{
	int count,sum,max,min, b0,b1,b2,temp,i,j;

	sum = 0;
	count = 0;
	for(i=100;i<1000;i++)
	{
		for(j=2;j<i;j++)
		{
			if (i%j==0)
			{
				break;
			}
		}

		if (j==i)
		{
			count++;

			printf("%-5d", i);
			if (count %10 == 0)
			{
				printf("\n");
			}

			b2 = i/100;
			b1 = (i-b2*100)/10;
			b0 = i-b2*100-b1*10;

			temp = b0*100+b1*10+b2;

			if (count == 1)
			{
				max = temp;
				min = temp;
			}
			else
			{
				if (max < temp)
				{
					max = temp;
				}
				if (min > temp)
				{
					min = temp;
				}
			}

			sum = sum+temp;
		}
	}

	if (count%10 != 0)
	{
		printf("\n");
	}

	printf("ƽ��ֵΪ%lf\n",(sum-max-min)/(double)(count-2));
}