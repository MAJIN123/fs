#include <stdio.h>

void main()
{
	int a[1000],count=0,i,j,b0,b1,b2,min_inx,temp,sum=0;

	for(i=100;i<1000;i++)
	{
		for(j=2;j<i;j++)
		{
			if (i%j==0)
			{
				break;
			}
		}
		if(j==i)
		{
			a[count++]=i;
		}
	}

	for(i=0;i<count;i++)
	{
		printf("%-5d",a[i]);

		if( (i+1)%10 == 0)
		{
			printf("\n");
		}
	}
	if( i%10 != 0)
	{
		printf("\n");
	}

	for(i=0;i<count;i++)
	{
		b2 = a[i]/100;
		b1 = (a[i]-b2*100)/10;
		b0 = a[i]-b2*100-b1*10;

		a[i] = b0*100+b1*10+b2;
		sum+=a[i];
	}

	for(i=0;i<count-1;i++)
	{
		min_inx = i;

		for(j=i+1;j<count;j++)
		{
			if (a[j] < a[min_inx])
			{
				min_inx = j;
			}
		}

		if (min_inx != i)
		{
			temp = a[i];
			a[i] = a[min_inx];
			a[min_inx] = temp;
		}
	}

	printf("ƽ��ֵΪ%lf\n",(sum-a[0]-a[count-1])/(double)(count-2));
}